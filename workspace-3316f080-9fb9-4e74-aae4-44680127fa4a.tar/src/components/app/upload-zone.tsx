"use client";

import { useCallback, useRef, useState } from "react";
import {
  Upload,
  X,
  FileImage,
  AlertCircle,
  Loader2,
  CheckCircle2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { processImage, dataUrlSize } from "@/lib/image-processing";

export interface UploadedImage {
  id: string;
  name: string;
  dataUrl: string;
  size: number;
  originalSize: number;
}

interface UploadZoneProps {
  images: UploadedImage[];
  onAdd: (imgs: UploadedImage[]) => void;
  onRemove: (id: string) => void;
  onClear: () => void;
  disabled?: boolean;
}

const MAX_SIZE_MB = 20;
const ACCEPTED = [
  "image/png",
  "image/jpeg",
  "image/jpg",
  "image/webp",
  "image/bmp",
  "image/gif",
];
// 1024px es suficiente para OCR de texto manuscrito/impreso y acelera drásticamente el análisis VLM
const MAX_DIMENSION = 1024;
const JPEG_QUALITY = 0.75;

export function UploadZone({
  images,
  onAdd,
  onRemove,
  onClear,
  disabled,
}: UploadZoneProps) {
  const [dragging, setDragging] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [processing, setProcessing] = useState(false);
  const [progress, setProgress] = useState<{
    current: number;
    total: number;
  } | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFiles = useCallback(
    async (fileList: FileList | null) => {
      if (!fileList || fileList.length === 0) return;
      setError(null);
      setProcessing(true);
      const nuevos: UploadedImage[] = [];
      const files = Array.from(fileList);
      setProgress({ current: 0, total: files.length });
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        setProgress({ current: i + 1, total: files.length });
        try {
          if (!ACCEPTED.includes(file.type)) {
            setError(
              `El archivo "${file.name}" no es una imagen soportada (formatos: PNG, JPG, WEBP, BMP, GIF).`
            );
            continue;
          }
          if (file.size > MAX_SIZE_MB * 1024 * 1024) {
            setError(
              `El archivo "${file.name}" excede ${MAX_SIZE_MB} MB. Intenta reducir su tamaño o tomar una captura de pantalla.`
            );
            continue;
          }
          // Preprocesar: corregir orientación EXIF, redimensionar, comprimir
          const dataUrl = await processImage(file, {
            maxDimension: MAX_DIMENSION,
            quality: JPEG_QUALITY,
          });
          nuevos.push({
            id: `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`,
            name: file.name,
            dataUrl,
            size: dataUrlSize(dataUrl),
            originalSize: file.size,
          });
        } catch (e) {
          console.error(`Error procesando ${file.name}:`, e);
          setError(
            `No se pudo procesar "${file.name}". Intenta con otra imagen.`
          );
        }
      }
      if (nuevos.length > 0) onAdd(nuevos);
      setProcessing(false);
      setProgress(null);
    },
    [onAdd]
  );

  return (
    <div className="space-y-3">
      <div
        role="button"
        tabIndex={0}
        onClick={() => !disabled && !processing && inputRef.current?.click()}
        onKeyDown={(e) => {
          if (
            (e.key === "Enter" || e.key === " ") &&
            !disabled &&
            !processing
          ) {
            e.preventDefault();
            inputRef.current?.click();
          }
        }}
        onDragOver={(e) => {
          e.preventDefault();
          if (!disabled && !processing) setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragging(false);
          if (!disabled && !processing) handleFiles(e.dataTransfer.files);
        }}
        className={cn(
          "relative flex flex-col items-center justify-center gap-2 rounded-lg border-2 border-dashed p-8 transition cursor-pointer",
          dragging
            ? "border-primary bg-primary/5"
            : "border-border hover:border-primary/60 hover:bg-muted/40",
          (disabled || processing) &&
            "opacity-60 cursor-not-allowed pointer-events-none"
        )}
      >
        <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary">
          {processing ? (
            <Loader2 className="h-6 w-6 animate-spin" />
          ) : (
            <Upload className="h-6 w-6" />
          )}
        </div>
        <p className="text-sm font-medium text-foreground">
          {processing
            ? "Procesando imagen…"
            : "Arrastra aquí las capturas de la queja"}
        </p>
        <p className="text-xs text-muted-foreground">
          o haz clic para seleccionar archivos · PNG, JPG, WEBP, BMP, GIF · las
          fotos se optimizan automáticamente
        </p>
        <input
          ref={inputRef}
          type="file"
          accept={ACCEPTED.join(",")}
          multiple
          className="hidden"
          onChange={(e) => {
            handleFiles(e.target.files);
            e.target.value = "";
          }}
        />
      </div>

      {(processing || error) && (
        <div className="space-y-2">
          {processing && progress && (
            <div className="flex items-center gap-2 rounded-md border border-primary/30 bg-primary/5 px-3 py-2 text-sm text-primary">
              <Loader2 className="h-4 w-4 animate-spin" />
              <span>
                Optimizando imagen {progress.current} de {progress.total}…
                (corrigiendo orientación, redimensionando y comprimiendo)
              </span>
            </div>
          )}
          {error && !processing && (
            <div className="flex items-center gap-2 rounded-md border border-destructive/40 bg-destructive/5 px-3 py-2 text-sm text-destructive">
              <AlertCircle className="h-4 w-4" />
              <span>{error}</span>
            </div>
          )}
        </div>
      )}

      {images.length > 0 && (
        <div className="flex items-center justify-between">
          <p className="text-xs text-muted-foreground">
            {images.length}{" "}
            {images.length === 1 ? "imagen cargada" : "imágenes cargadas"}
          </p>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={onClear}
            disabled={disabled}
            className="h-7 text-xs"
          >
            <X className="h-3.5 w-3.5" /> Limpiar
          </Button>
        </div>
      )}

      {images.length > 0 && (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {images.map((img) => (
            <Card key={img.id} className="group relative overflow-hidden p-0">
              <CardContent className="p-0">
                <div className="relative aspect-square w-full bg-muted">
                  <img
                    src={img.dataUrl}
                    alt={img.name}
                    className="h-full w-full object-cover"
                  />
                  <button
                    type="button"
                    onClick={() => onRemove(img.id)}
                    disabled={disabled}
                    className="absolute right-1 top-1 flex h-6 w-6 items-center justify-center rounded-full bg-black/60 text-white opacity-100 transition hover:bg-destructive"
                    aria-label="Quitar imagen"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>
                <div className="space-y-0.5 px-2 py-1.5">
                  <div className="flex items-center gap-1.5">
                    <FileImage className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                    <span className="truncate text-[11px] text-muted-foreground">
                      {img.name}
                    </span>
                  </div>
                  {img.originalSize > 0 && (
                    <div className="flex items-center gap-1 text-[10px] text-emerald-600">
                      <CheckCircle2 className="h-2.5 w-2.5" />
                      <span>
                        {(img.originalSize / 1024 / 1024).toFixed(1)} MB →{" "}
                        {(img.size / 1024).toFixed(0)} KB
                      </span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
