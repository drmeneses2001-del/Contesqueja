"use client";

import { useCallback, useRef, useState } from "react";
import { toast } from "sonner";
import { motion, AnimatePresence } from "framer-motion";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  ImageUp,
  Wand2,
  Loader2,
  FileSearch,
  StepForward,
  CheckCircle2,
  Info,
} from "lucide-react";
import { UploadZone, type UploadedImage } from "./upload-zone";
import { AnalysisCard, type AnalisisQueja } from "./analysis-card";
import {
  ConfigPanel,
  CONFIG_DEFAULT,
  type ConfiguracionRespuesta,
} from "./config-panel";
import { ResponsePanel } from "./response-panel";

type Paso = 1 | 2 | 3;

interface RespuestaGenerada {
  respuesta: string;
  meta: {
    estilo: string;
    tono: string;
    tamano: string;
    complejidad: string;
    generado_en: string;
  };
}

export function QuejaApp() {
  const [imagenes, setImagenes] = useState<UploadedImage[]>([]);
  const [analisis, setAnalisis] = useState<AnalisisQueja | null>(null);
  const [config, setConfig] = useState<ConfiguracionRespuesta>(CONFIG_DEFAULT);
  const [respuesta, setRespuesta] = useState<RespuestaGenerada | null>(null);

  const [analizando, setAnalizando] = useState(false);
  const [generando, setGenerando] = useState(false);
  const [paso, setPaso] = useState<Paso>(1);
  const [tiempoTranscurrido, setTiempoTranscurrido] = useState(0);
  const pollingRef = useRef<NodeJS.Timeout | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const addImagenes = (nuevas: UploadedImage[]) =>
    setImagenes((prev) => [...prev, ...nuevas]);
  const removeImagen = (id: string) =>
    setImagenes((prev) => prev.filter((i) => i.id !== id));
  const clearImagenes = () => setImagenes([]);

  // Limpia timers al desmontar
  const cleanupTimers = useCallback(() => {
    if (pollingRef.current) {
      clearInterval(pollingRef.current);
      pollingRef.current = null;
    }
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  /**
   * Ejecuta una tarea asíncrona en el servidor usando el patrón POST + polling GET.
   * - POST inicia el trabajo y devuelve { jobId }
   * - GET /api/<endpoint>?id=<jobId> consulta el estado cada 3s
   * - Devuelve el resultado cuando status === "done"
   * - Lanza error si status === "error" o si pasan MAX_WAIT segundos
   */
  const runWithPolling = useCallback(
    async <T,>(
      endpoint: "/api/analyze" | "/api/generate",
      body: unknown,
      onProgress?: (elapsedSec: number) => void
    ): Promise<T> => {
      // 1. POST: iniciar trabajo
      const postRes = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (!postRes.ok) {
        let msg = `Error del servidor (${postRes.status})`;
        try {
          const err = await postRes.json();
          msg = err.error || err.detail || msg;
        } catch {
          /* respuesta no JSON */
        }
        throw new Error(msg);
      }
      const { jobId } = (await postRes.json()) as { jobId: string };
      if (!jobId) throw new Error("El servidor no devolvió un jobId.");

      // 2. Polling: consultar estado cada 3 segundos
      const POLL_INTERVAL_MS = 3000;
      const MAX_WAIT_MS = 10 * 60 * 1000; // 10 minutos máximo (el VLM puede tardar varios minutos)
      const startTime = Date.now();

      return new Promise<T>((resolve, reject) => {
        const poll = async () => {
          const elapsed = Date.now() - startTime;
          if (elapsed > MAX_WAIT_MS) {
            cleanupTimers();
            reject(
              new Error(
                "El análisis superó el tiempo máximo de espera (10 minutos). El servidor puede estar saturado. Intenta nuevamente en unos minutos."
              )
            );
            return;
          }

          if (onProgress) {
            onProgress(Math.floor(elapsed / 1000));
          }

          try {
            const getRes = await fetch(`${endpoint}?id=${jobId}`);
            if (!getRes.ok && getRes.status !== 404) {
              const err = await getRes.json().catch(() => ({}));
              cleanupTimers();
              reject(new Error(err.error || `Error consultando estado (${getRes.status})`));
              return;
            }
            if (getRes.status === 404) {
              cleanupTimers();
              reject(new Error("El trabajo expiró. Intenta nuevamente."));
              return;
            }
            const data = (await getRes.json()) as {
              status: string;
              result?: T;
              error?: string;
            };

            if (data.status === "done" && data.result) {
              cleanupTimers();
              resolve(data.result);
            } else if (data.status === "error") {
              cleanupTimers();
              reject(new Error(data.error || "Error en el procesamiento."));
            }
            // Si status es "pending" o "processing", seguir esperando
            // (el intervalo volverá a ejecutar poll)
          } catch (e) {
            // Errores de red temporales: no abortar, solo log
            console.warn("Error temporal en polling:", e);
          }
        };

        // Ejecutar inmediatamente y luego cada 3s
        poll();
        pollingRef.current = setInterval(poll, POLL_INTERVAL_MS);
      });
    },
    [cleanupTimers]
  );

  const analizar = useCallback(async () => {
    if (imagenes.length === 0) {
      toast.error("Agrega al menos una captura de la queja.");
      return;
    }
    setAnalizando(true);
    setAnalisis(null);
    setRespuesta(null);
    setTiempoTranscurrido(0);
    const toastId = toast.loading("Iniciando análisis…");

    // Timer para actualizar el contador de tiempo
    timerRef.current = setInterval(() => {
      setTiempoTranscurrido((t) => t + 1);
    }, 1000);

    try {
      const result = await runWithPolling<AnalisisQueja>(
        "/api/analyze",
        { images: imagenes.map((i) => i.dataUrl) },
        (elapsedSec) => {
          setTiempoTranscurrido(elapsedSec);
          let msg: string;
          if (elapsedSec < 30) {
            msg = `Analizando la queja… ${elapsedSec}s. El servidor está procesando la imagen.`;
          } else if (elapsedSec < 90) {
            msg = `Analizando la queja… ${elapsedSec}s. La IA está extrayendo el texto de la imagen.`;
          } else if (elapsedSec < 180) {
            msg = `Analizando la queja… ${elapsedSec}s. La IA está estructurando la información.`;
          } else if (elapsedSec < 300) {
            msg = `Analizando la queja… ${elapsedSec}s. Casi listo, la IA está finalizando el análisis.`;
          } else {
            msg = `Analizando la queja… ${elapsedSec}s. El análisis está tardando más de lo habitual, pero sigue en curso. Por favor espera.`;
          }
          toast.loading(msg, { id: toastId });
        }
      );

      const parsed = result;
      if (!parsed.texto_completo && !parsed.resumen?.motivo_queja) {
        throw new Error(
          "No se pudo extraer información de la imagen. Asegúrate de que la captura sea legible y contenga texto de la queja."
        );
      }
      setAnalisis(parsed);
      setPaso(2);
      toast.success("Análisis completado.", { id: toastId });
    } catch (e) {
      console.error(e);
      let msg = "No se pudo analizar la queja.";
      if (e instanceof Error) {
        const m = e.message;
        if (m.includes("502") || m.includes("Failed to reach upstream")) {
          msg =
            "El servicio de IA está temporalmente saturado. El sistema reintentó automáticamente varias veces pero no pudo completar el análisis. Por favor intenta nuevamente en 1-2 minutos.";
        } else if (m.includes("503")) {
          msg =
            "El servicio de IA no está disponible en este momento. Intenta nuevamente en unos minutos.";
        } else if (m.includes("tiempo máximo de espera")) {
          msg = m;
        } else {
          msg = m;
        }
      }
      toast.error(msg, { id: toastId, duration: 12000 });
    } finally {
      cleanupTimers();
      setAnalizando(false);
      setTiempoTranscurrido(0);
    }
  }, [imagenes, runWithPolling, cleanupTimers]);

  const generar = useCallback(
    async (regenerar = false) => {
      if (!analisis) {
        toast.error("Primero analiza la queja.");
        return;
      }
      setGenerando(true);
      setTiempoTranscurrido(0);
      const toastId = toast.loading(
        regenerar
          ? "Iniciando regeneración…"
          : "Iniciando redacción de la contestación…"
      );

      timerRef.current = setInterval(() => {
        setTiempoTranscurrido((t) => t + 1);
      }, 1000);

      try {
        const result = await runWithPolling<RespuestaGenerada>(
          "/api/generate",
          {
            analisis,
            estilo: config.estilo,
            tono: config.tono,
            tamano: config.tamano,
            complejidad: config.complejidad,
            sugerencias: config.sugerencias,
            firmante: config.firmante,
            cargo_firmante: config.cargo_firmante,
            nombre_paciente: config.nombre_paciente,
          },
          (elapsedSec) => {
            setTiempoTranscurrido(elapsedSec);
            toast.loading(
              `${
                regenerar ? "Regenerando" : "Redactando"
              } la contestación… ${elapsedSec}s transcurridos.`,
              { id: toastId }
            );
          }
        );

        setRespuesta(result);
        setPaso(3);
        toast.success(
          regenerar ? "Respuesta regenerada." : "Respuesta generada.",
          { id: toastId }
        );
      } catch (e) {
        console.error(e);
        const msg =
          e instanceof Error ? e.message : "No se pudo generar la respuesta.";
        toast.error(msg, { id: toastId, duration: 10000 });
      } finally {
        cleanupTimers();
        setGenerando(false);
        setTiempoTranscurrido(0);
      }
    },
    [analisis, config, runWithPolling, cleanupTimers]
  );

  const reset = () => {
    setImagenes([]);
    setAnalisis(null);
    setRespuesta(null);
    setPaso(1);
  };

  return (
    <div className="space-y-6">
      {/* Stepper */}
      <div className="flex flex-wrap items-center gap-2 text-xs">
        <PasoChip n={1} label="Capturas" active={paso === 1} done={paso > 1} />
        <StepForward className="h-3.5 w-3.5 text-muted-foreground" />
        <PasoChip
          n={2}
          label="Análisis y configuración"
          active={paso === 2}
          done={paso > 2}
        />
        <StepForward className="h-3.5 w-3.5 text-muted-foreground" />
        <PasoChip
          n={3}
          label="Respuesta y PDF"
          active={paso === 3}
          done={false}
        />
      </div>

      {/* PASO 1: Carga de imágenes */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <ImageUp className="h-4 w-4 text-primary" />
            1 · Capturas de la queja
          </CardTitle>
          <CardDescription className="text-xs">
            Sube las capturas de pantalla del mensaje, oficio, correo o
            documento de la queja. La IA extraerá el texto y estructurará los
            hechos para contestarla.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <UploadZone
            images={imagenes}
            onAdd={addImagenes}
            onRemove={removeImagen}
            onClear={clearImagenes}
            disabled={analizando}
          />

          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-start gap-2 rounded-md bg-sky-50 px-3 py-2 text-xs text-sky-900">
              <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" />
              <p>
                Recomendación: usa capturas nítidas, con buen contraste. Puedes
                agregar varias imágenes si la queja continúa en varias
                pantallas.
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              {paso > 1 && (
                <Button variant="ghost" size="sm" onClick={reset}>
                  Empezar de nuevo
                </Button>
              )}
              <Button
                onClick={analizar}
                disabled={imagenes.length === 0 || analizando}
                size="sm"
              >
                {analizando ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Analizando… {tiempoTranscurrido > 0 ? `${tiempoTranscurrido}s` : ""}
                  </>
                ) : (
                  <>
                    <FileSearch className="h-4 w-4" />
                    Analizar queja
                  </>
                )}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* PASO 2: Análisis + Configuración */}
      <AnimatePresence>
        {analisis && (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="grid grid-cols-1 gap-6 lg:grid-cols-2"
          >
            <div className="space-y-4">
              <h2 className="flex items-center gap-2 text-sm font-semibold">
                <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                2 · Análisis estructurado
              </h2>
              <AnalysisCard analisis={analisis} />
            </div>

            <div className="space-y-4">
              <h2 className="flex items-center gap-2 text-sm font-semibold">
                <Wand2 className="h-4 w-4 text-primary" />
                3 · Personaliza la respuesta
              </h2>
              <ConfigPanel value={config} onChange={setConfig} disabled={generando} />

              <div className="flex justify-end">
                <Button
                  onClick={() => generar(false)}
                  disabled={generando}
                  size="sm"
                >
                  {generando ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Generando… {tiempoTranscurrido > 0 ? `${tiempoTranscurrido}s` : ""}
                    </>
                  ) : (
                    <>
                      <Wand2 className="h-4 w-4" />
                      Generar contestación
                    </>
                  )}
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* PASO 3: Respuesta generada */}
      <AnimatePresence>
        {respuesta && (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="space-y-4"
          >
            <h2 className="flex items-center gap-2 text-sm font-semibold">
              <CheckCircle2 className="h-4 w-4 text-emerald-600" />
              4 · Contestación lista
            </h2>
            <ResponsePanel
              respuesta={respuesta.respuesta}
              meta={respuesta.meta}
              analisis={analisis ?? undefined}
              config={config}
              onRegenerate={() => generar(true)}
              regenerating={generando}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function PasoChip({
  n,
  label,
  active,
  done,
}: {
  n: number;
  label: string;
  active: boolean;
  done: boolean;
}) {
  return (
    <div
      className={
        "flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs transition " +
        (active
          ? "border-primary bg-primary text-primary-foreground"
          : done
            ? "border-emerald-200 bg-emerald-50 text-emerald-700"
            : "border-border bg-muted/40 text-muted-foreground")
      }
    >
      <span
        className={
          "flex h-4 w-4 items-center justify-center rounded-full text-[10px] font-bold " +
          (active
            ? "bg-primary-foreground text-primary"
            : done
              ? "bg-emerald-600 text-white"
              : "bg-muted-foreground/20 text-muted-foreground")
        }
      >
        {done ? "✓" : n}
      </span>
      {label}
    </div>
  );
}
