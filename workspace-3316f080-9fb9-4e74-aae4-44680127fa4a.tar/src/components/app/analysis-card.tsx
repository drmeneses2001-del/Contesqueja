"use client";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Building2,
  Calendar,
  User,
  Hash,
  MapPin,
  FolderTree,
  ShieldAlert,
  Scale,
  ListTree,
  FileText,
} from "lucide-react";

export interface AnalisisQueja {
  texto_completo?: string;
  resumen?: {
    motivo_queja?: string;
    institucion_mencionada?: string;
    fecha_hechos?: string;
    lugar_hechos?: string;
    datos_usuario?: string;
    folio_queja?: string;
    area_responsable?: string;
  };
  clasificacion?: {
    tipo?: string;
    gravedad?: string;
    urgencia?: string;
  };
  hechos_clave?: string[];
  pretension_usuario?: string;
  normas_potencialmente_aplicables?: string[];
  _aviso?: string;
}

const GRAVEDAD_COLOR: Record<string, string> = {
  Alta: "bg-red-100 text-red-800 border-red-200",
  Media: "bg-amber-100 text-amber-800 border-amber-200",
  Baja: "bg-emerald-100 text-emerald-800 border-emerald-200",
};

const URGENCIA_COLOR: Record<string, string> = {
  Inmediata: "bg-red-100 text-red-800 border-red-200",
  Prioritaria: "bg-orange-100 text-orange-800 border-orange-200",
  Programable: "bg-sky-100 text-sky-800 border-sky-200",
};

function Field({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value?: string;
}) {
  return (
    <div className="flex items-start gap-2 rounded-md border bg-card p-2.5">
      <div className="mt-0.5 text-muted-foreground">{icon}</div>
      <div className="min-w-0 flex-1">
        <p className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
          {label}
        </p>
        <p className="text-sm text-foreground break-words">
          {value && value.trim() ? value : "No especificado"}
        </p>
      </div>
    </div>
  );
}

export function AnalysisCard({ analisis }: { analisis: AnalisisQueja }) {
  const r = analisis.resumen ?? {};
  const c = analisis.clasificacion ?? {};
  const hechos = analisis.hechos_clave ?? [];
  const normas = analisis.normas_potencialmente_aplicables ?? [];

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <CardTitle className="text-base">Resumen de la queja</CardTitle>
              <CardDescription className="text-xs">
                Información estructurada extraída por la IA
              </CardDescription>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {c.tipo && (
                <Badge variant="secondary" className="text-xs">
                  {c.tipo}
                </Badge>
              )}
              {c.gravedad && (
                <Badge
                  variant="outline"
                  className={
                    "text-xs " + (GRAVEDAD_COLOR[c.gravedad] ?? "")
                  }
                >
                  <ShieldAlert className="mr-1 h-3 w-3" /> Gravedad {c.gravedad}
                </Badge>
              )}
              {c.urgencia && (
                <Badge
                  variant="outline"
                  className={
                    "text-xs " + (URGENCIA_COLOR[c.urgencia] ?? "")
                  }
                >
                  ⏱ Urgencia {c.urgencia}
                </Badge>
              )}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            <Field
              icon={<Hash className="h-4 w-4" />}
              label="Folio"
              value={r.folio_queja}
            />
            <Field
              icon={<Calendar className="h-4 w-4" />}
              label="Fecha de los hechos"
              value={r.fecha_hechos}
            />
            <Field
              icon={<User className="h-4 w-4" />}
              label="Quejoso(a)"
              value={r.datos_usuario}
            />
            <Field
              icon={<Building2 className="h-4 w-4" />}
              label="Institución"
              value={r.institucion_mencionada}
            />
            <Field
              icon={<MapPin className="h-4 w-4" />}
              label="Lugar de los hechos"
              value={r.lugar_hechos}
            />
            <Field
              icon={<FolderTree className="h-4 w-4" />}
              label="Área responsable"
              value={r.area_responsable}
            />
            <div className="sm:col-span-2">
              <Field
                icon={<FileText className="h-4 w-4" />}
                label="Motivo de la queja"
                value={r.motivo_queja}
              />
            </div>
            {analisis.pretension_usuario && (
              <div className="sm:col-span-2">
                <Field
                  icon={<Scale className="h-4 w-4" />}
                  label="Pretensión del usuario"
                  value={analisis.pretension_usuario}
                />
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {hechos.length > 0 && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-sm">
              <ListTree className="h-4 w-4 text-primary" />
              Hechos clave
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ol className="list-inside list-decimal space-y-1 text-sm text-foreground">
              {hechos.map((h, i) => (
                <li key={i} className="leading-relaxed">
                  {h}
                </li>
              ))}
            </ol>
          </CardContent>
        </Card>
      )}

      {normas.length > 0 && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-sm">
              <Scale className="h-4 w-4 text-primary" />
              Normas potencialmente aplicables
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-1.5">
              {normas.map((n, i) => (
                <Badge key={i} variant="outline" className="text-xs">
                  {n}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {analisis.texto_completo && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Texto extraído</CardTitle>
          </CardHeader>
          <CardContent>
            <pre className="max-h-72 overflow-y-auto whitespace-pre-wrap break-words rounded-md bg-muted/40 p-3 text-xs leading-relaxed text-foreground">
              {analisis.texto_completo}
            </pre>
          </CardContent>
        </Card>
      )}

      {analisis._aviso && (
        <div className="rounded-md border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800">
          {analisis._aviso}
        </div>
      )}
    </div>
  );
}
