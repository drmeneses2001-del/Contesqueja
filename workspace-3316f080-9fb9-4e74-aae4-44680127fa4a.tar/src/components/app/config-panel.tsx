"use client";

import { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  HelpCircle,
  Sparkles,
  Sliders,
  Ruler,
  Layers,
  FileText,
  User,
} from "lucide-react";

export type Estilo =
  | "formal_institucional"
  | "empatico_cercano"
  | "tecnic_juridico"
  | "conciso_directo";
export type Tono =
  | "neutral_profesional"
  | "calido_humanizado"
  | "enérgico_decidido"
  | "disculpa_reparador";
export type Tamano = "corto" | "medio" | "extenso";
export type Complejidad =
  | "sencillo_legible"
  | "intermedio"
  | "alta_especializacion_juridica";

export interface DatosOficio {
  numero_oficio: string;
  area_emisora: string;
  destinatario_nombre: string;
  destinatario_cargo: string;
  asunto: string;
  fecha_emision: string;
  firmante_nombre: string;
  firmante_cargo: string;
  ano_conmemorativo: string;
  direccion_institucion: string;
}

export interface ConfiguracionRespuesta {
  estilo: Estilo;
  tono: Tono;
  tamano: Tamano;
  complejidad: Complejidad;
  sugerencias: string;
  firmante: string;
  cargo_firmante: string;
  nombre_paciente: string;
  oficio: DatosOficio;
}

export const OFICIO_DEFAULT: DatosOficio = {
  numero_oficio: "",
  area_emisora: "COORDINACIÓN DE GINECOLOGÍA Y OBSTETRICIA",
  destinatario_nombre: "",
  destinatario_cargo: "COORD. DE ATENCIÓN AL DERECHOHABIENTE",
  asunto: "",
  fecha_emision: "",
  firmante_nombre: "",
  firmante_cargo: "",
  ano_conmemorativo: "2026, año de Margarita Maza",
  direccion_institucion:
    "Av. Universidad No. 1321, Col. Axotla, C.P. 01030, alcaldía Álvaro Obregón, CDMX, Tel. (55) 5322-2300",
};

export const CONFIG_DEFAULT: ConfiguracionRespuesta = {
  estilo: "formal_institucional",
  tono: "neutral_profesional",
  tamano: "medio",
  complejidad: "intermedio",
  sugerencias: "",
  firmante: "",
  cargo_firmante: "",
  nombre_paciente: "",
  oficio: { ...OFICIO_DEFAULT },
};

interface ConfigPanelProps {
  value: ConfiguracionRespuesta;
  onChange: (v: ConfiguracionRespuesta) => void;
  disabled?: boolean;
}

function FieldLabel({
  icon,
  label,
  hint,
}: {
  icon: React.ReactNode;
  label: string;
  hint: string;
}) {
  return (
    <div className="flex items-center gap-1.5">
      {icon}
      <Label className="text-xs font-medium">{label}</Label>
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <button
              type="button"
              className="text-muted-foreground hover:text-foreground"
              aria-label={`Ayuda sobre ${label}`}
            >
              <HelpCircle className="h-3.5 w-3.5" />
            </button>
          </TooltipTrigger>
          <TooltipContent className="max-w-xs text-xs">{hint}</TooltipContent>
        </Tooltip>
      </TooltipProvider>
    </div>
  );
}

export function ConfigPanel({ value, onChange, disabled }: ConfigPanelProps) {
  const update = <K extends keyof ConfiguracionRespuesta>(
    k: K,
    v: ConfiguracionRespuesta[K]
  ) => onChange({ ...value, [k]: v });

  const updateOficio = <K extends keyof DatosOficio>(
    k: K,
    v: DatosOficio[K]
  ) => onChange({ ...value, oficio: { ...value.oficio, [k]: v } });

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-base">
          <Sliders className="h-4 w-4 text-primary" />
          Configuración de la respuesta
        </CardTitle>
        <CardDescription className="text-xs">
          Personaliza el estilo, tono, extensión y complejidad del documento.
          La IA fundamentará la respuesta en la normatividad mexicana de salud
          e ISSSTE CDMX.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Nombre de la paciente — campo destacado */}
        <div className="rounded-md border border-rose-200 bg-rose-50/50 p-3">
          <div className="space-y-1.5">
            <div className="flex items-center gap-1.5">
              <User className="h-3.5 w-3.5 text-rose-700" />
              <Label className="text-xs font-semibold text-rose-900">
                Nombre de la paciente
              </Label>
              <span className="text-[10px] text-rose-700/70">
                (aparecerá en el saludo de la contestación)
              </span>
            </div>
            <Input
              value={value.nombre_paciente}
              onChange={(e) =>
                onChange({ ...value, nombre_paciente: e.target.value })
              }
              disabled={disabled}
              placeholder="Ej: María González Pérez (dejar vacío para usar 'Estimada paciente')"
              className="h-9 bg-white text-sm"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div className="space-y-1.5">
            <FieldLabel
              icon={<Sparkles className="h-3.5 w-3.5 text-primary" />}
              label="Estilo de redacción"
              hint="Define la estructura general del oficio: encabezado, saludo, despedida y forma de redactar."
            />
            <Select
              value={value.estilo}
              onValueChange={(v) => update("estilo", v as Estilo)}
              disabled={disabled}
            >
              <SelectTrigger className="h-9">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="formal_institucional">
                  Formal institucional
                </SelectItem>
                <SelectItem value="empatico_cercano">
                  Empático cercano
                </SelectItem>
                <SelectItem value="tecnic_juridico">
                  Técnico jurídico
                </SelectItem>
                <SelectItem value="conciso_directo">Conciso directo</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1.5">
            <FieldLabel
              icon={<Sparkles className="h-3.5 w-3.5 text-primary" />}
              label="Tono"
              hint="Actitud emocional del texto: si debe ser cálido, enérgico, apologético o neutral."
            />
            <Select
              value={value.tono}
              onValueChange={(v) => update("tono", v as Tono)}
              disabled={disabled}
            >
              <SelectTrigger className="h-9">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="neutral_profesional">
                  Neutral profesional
                </SelectItem>
                <SelectItem value="calido_humanizado">
                  Cálido humanizado
                </SelectItem>
                <SelectItem value="enérgico_decidido">
                  Enérgico decidido
                </SelectItem>
                <SelectItem value="disculpa_reparador">
                  Disculpa reparador
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1.5">
            <FieldLabel
              icon={<Ruler className="h-3.5 w-3.5 text-primary" />}
              label="Tamaño / extensión"
              hint="Cantidad de palabras y secciones del documento final."
            />
            <Select
              value={value.tamano}
              onValueChange={(v) => update("tamano", v as Tamano)}
              disabled={disabled}
            >
              <SelectTrigger className="h-9">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="corto">Corto (250-350 palabras)</SelectItem>
                <SelectItem value="medio">Medio (500-800 palabras)</SelectItem>
                <SelectItem value="extenso">
                  Extenso (1000-1500 palabras)
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1.5">
            <FieldLabel
              icon={<Layers className="h-3.5 w-3.5 text-primary" />}
              label="Complejidad"
              hint="Nivel de tecnicismo del lenguaje: ciudadano, profesional o jurídico avanzado."
            />
            <Select
              value={value.complejidad}
              onValueChange={(v) => update("complejidad", v as Complejidad)}
              disabled={disabled}
            >
              <SelectTrigger className="h-9">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="sencillo_legible">
                  Sencillo y legible
                </SelectItem>
                <SelectItem value="intermedio">Intermedio</SelectItem>
                <SelectItem value="alta_especializacion_juridica">
                  Alta especialización jurídica
                </SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-1.5">
          <FieldLabel
            icon={<Sparkles className="h-3.5 w-3.5 text-primary" />}
            label="Sugerencias y comentarios"
            hint="Indica qué puntos específicos debe tocar, evitar o enfatizar la respuesta. Ej: 'mencionar disculpa por la espera', 'ofrecer cita prioritaria', 'omitir referencias a sanciones'."
          />
          <Textarea
            value={value.sugerencias}
            onChange={(e) => update("sugerencias", e.target.value)}
            disabled={disabled}
            rows={3}
            placeholder="Ej: Solicitamos que la respuesta incluya una disculpa explícita por la demora, ofrezca reprogramación de cita en un plazo máximo de 5 días hábiles, y cite el Artículo 51 de la Ley General de Salud."
            className="text-sm"
          />
        </div>

        {/* Datos del oficio (colapsable) */}
        <Accordion type="single" collapsible defaultValue="oficio">
          <AccordionItem value="oficio" className="border rounded-md px-3">
            <AccordionTrigger className="py-3 text-sm hover:no-underline">
              <div className="flex items-center gap-2">
                <FileText className="h-4 w-4 text-primary" />
                Datos del oficio institucional
              </div>
            </AccordionTrigger>
            <AccordionContent className="space-y-3 pt-2">
              <p className="text-[11px] text-muted-foreground">
                Estos datos se reflejan en el PDF exportado siguiendo el formato
                del Hospital Regional &quot;Lic. Adolfo López Mateos&quot; del
                ISSSTE. Si dejas un campo vacío, se usará un valor por defecto o
                se inferirá del análisis de la queja.
              </p>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">
                    Número de oficio
                  </Label>
                  <Input
                    value={value.oficio.numero_oficio}
                    onChange={(e) =>
                      updateOficio("numero_oficio", e.target.value)
                    }
                    disabled={disabled}
                    placeholder="Ej: CGO/1234/2026"
                    className="h-9 text-sm"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">
                    Área emisora (coordinación)
                  </Label>
                  <Input
                    value={value.oficio.area_emisora}
                    onChange={(e) =>
                      updateOficio("area_emisora", e.target.value)
                    }
                    disabled={disabled}
                    placeholder="Ej: Coordinación de Ginecología y Obstetricia"
                    className="h-9 text-sm"
                  />
                </div>

                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">
                    Nombre del destinatario
                  </Label>
                  <Input
                    value={value.oficio.destinatario_nombre}
                    onChange={(e) =>
                      updateOficio("destinatario_nombre", e.target.value)
                    }
                    disabled={disabled}
                    placeholder="Ej: Lic. María del Rocío Paz Oropeza"
                    className="h-9 text-sm"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">
                    Cargo del destinatario
                  </Label>
                  <Input
                    value={value.oficio.destinatario_cargo}
                    onChange={(e) =>
                      updateOficio("destinatario_cargo", e.target.value)
                    }
                    disabled={disabled}
                    placeholder="Ej: Coord. de Atención al Derechohabiente"
                    className="h-9 text-sm"
                  />
                </div>

                <div className="space-y-1.5 sm:col-span-2">
                  <Label className="text-xs font-medium">Asunto</Label>
                  <Input
                    value={value.oficio.asunto}
                    onChange={(e) => updateOficio("asunto", e.target.value)}
                    disabled={disabled}
                    placeholder="Ej: Contestación a queja por denegación de servicio médico"
                    className="h-9 text-sm"
                  />
                </div>

                <div className="space-y-1.5 sm:col-span-2">
                  <Label className="text-xs font-medium">
                    Fecha de emisión
                  </Label>
                  <Input
                    value={value.oficio.fecha_emision}
                    onChange={(e) =>
                      updateOficio("fecha_emision", e.target.value)
                    }
                    disabled={disabled}
                    placeholder='Ej: "Ciudad de México, a 7 de julio de 2026" (vacío = fecha actual)'
                    className="h-9 text-sm"
                  />
                </div>

                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">
                    Nombre del firmante
                  </Label>
                  <Input
                    value={value.oficio.firmante_nombre}
                    onChange={(e) =>
                      updateOficio("firmante_nombre", e.target.value)
                    }
                    disabled={disabled}
                    placeholder="Ej: Dr. Juan Pérez Gómez"
                    className="h-9 text-sm"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">
                    Cargo del firmante
                  </Label>
                  <Input
                    value={value.oficio.firmante_cargo}
                    onChange={(e) =>
                      updateOficio("firmante_cargo", e.target.value)
                    }
                    disabled={disabled}
                    placeholder="Ej: Coordinador de Ginecología y Obstetricia"
                    className="h-9 text-sm"
                  />
                </div>

                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">
                    Año conmemorativo (pie de página)
                  </Label>
                  <Input
                    value={value.oficio.ano_conmemorativo}
                    onChange={(e) =>
                      updateOficio("ano_conmemorativo", e.target.value)
                    }
                    disabled={disabled}
                    placeholder="Ej: 2026, año de Margarita Maza"
                    className="h-9 text-sm"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-medium">
                    Dirección de la institución
                  </Label>
                  <Input
                    value={value.oficio.direccion_institucion}
                    onChange={(e) =>
                      updateOficio("direccion_institucion", e.target.value)
                    }
                    disabled={disabled}
                    placeholder="Av. Universidad No. 1321..."
                    className="h-9 text-sm"
                  />
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </CardContent>
    </Card>
  );
}
