"use client";

import { useState } from "react";
import { toast } from "sonner";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import {
  FileText,
  Download,
  Copy,
  RefreshCw,
  CheckCircle2,
} from "lucide-react";
import { descargarPdf } from "@/lib/pdf-client";
import type { ConfiguracionRespuesta } from "./config-panel";
import type { AnalisisQueja } from "./analysis-card";

interface ResponsePanelProps {
  respuesta: string;
  meta: {
    estilo: string;
    tono: string;
    tamano: string;
    complejidad: string;
    generado_en: string;
  };
  analisis: AnalisisQueja | undefined;
  config: ConfiguracionRespuesta;
  onRegenerate: () => void;
  regenerating: boolean;
}

export function ResponsePanel({
  respuesta,
  meta,
  analisis,
  config,
  onRegenerate,
  regenerating,
}: ResponsePanelProps) {
  const [copied, setCopied] = useState(false);

  const handleDownload = () => {
    try {
      descargarPdf(
        respuesta,
        analisis?.resumen
          ? {
              ...analisis.resumen,
              ...analisis.clasificacion,
            }
          : undefined,
        meta,
        {
          firmante: config.firmante,
          cargoFirmante: config.cargo_firmante,
          oficio: {
            ...config.oficio,
            nombre_paciente: config.nombre_paciente,
          },
        }
      );
      toast.success("PDF generado con formato institucional ISSSTE.");
    } catch (e) {
      console.error(e);
      toast.error("No se pudo generar el PDF.");
    }
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(respuesta);
      setCopied(true);
      toast.success("Respuesta copiada al portapapeles.");
      setTimeout(() => setCopied(false), 1800);
    } catch {
      toast.error("No se pudo copiar.");
    }
  };

  const fechaFormateada = new Date(meta.generado_en).toLocaleString("es-MX", {
    dateStyle: "long",
    timeStyle: "short",
  });

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <CardTitle className="flex items-center gap-2 text-base">
              <FileText className="h-4 w-4 text-primary" />
              Contestación generada
            </CardTitle>
            <CardDescription className="text-xs">
              Generada el {fechaFormateada}
            </CardDescription>
          </div>
          <div className="flex flex-wrap gap-1.5">
            <Badge variant="secondary" className="text-[10px]">
              {meta.estilo.replace(/_/g, " ")}
            </Badge>
            <Badge variant="secondary" className="text-[10px]">
              {meta.tono.replace(/_/g, " ")}
            </Badge>
            <Badge variant="secondary" className="text-[10px]">
              {meta.tamano}
            </Badge>
            <Badge variant="secondary" className="text-[10px]">
              {meta.complejidad.replace(/_/g, " ")}
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <Tabs defaultValue="documento">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <TabsList className="h-9">
              <TabsTrigger value="documento" className="text-xs">
                Documento
              </TabsTrigger>
              <TabsTrigger value="texto" className="text-xs">
                Texto plano
              </TabsTrigger>
            </TabsList>
            <div className="flex flex-wrap gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={handleCopy}
                className="h-8 text-xs"
              >
                {copied ? (
                  <CheckCircle2 className="h-3.5 w-3.5" />
                ) : (
                  <Copy className="h-3.5 w-3.5" />
                )}
                {copied ? "Copiado" : "Copiar"}
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={onRegenerate}
                disabled={regenerating}
                className="h-8 text-xs"
              >
                <RefreshCw
                  className={`h-3.5 w-3.5 ${regenerating ? "animate-spin" : ""}`}
                />
                {regenerating ? "Regenerando…" : "Regenerar"}
              </Button>
              <Button
                size="sm"
                onClick={handleDownload}
                className="h-8 text-xs"
              >
                <Download className="h-3.5 w-3.5" />
                Exportar PDF
              </Button>
            </div>
          </div>

          <TabsContent value="documento" className="mt-3">
            <div className="rounded-lg border bg-white p-6 shadow-sm">
              <div className="mx-auto max-w-2xl space-y-4">
                {/* Encabezado institucional */}
                <div className="flex items-start justify-between gap-3 border-b border-slate-300 pb-3">
                  <div className="flex items-center gap-2">
                    <img
                      src="/header_logos.png"
                      alt="Logos Gobierno de México · ISSSTE · Hospital López Mateos"
                      className="h-14 w-auto object-contain"
                    />
                  </div>
                  <div className="flex items-center">
                    <img
                      src="/header_ilustracion.png"
                      alt="Ilustración histórica"
                      className="h-16 w-auto object-contain opacity-80"
                    />
                  </div>
                </div>

                {/* Bloque jerárquico alineado a la derecha */}
                <div className="text-right">
                  <p className="text-[10px] font-bold text-slate-800">
                    DIRECCIÓN MÉDICA
                  </p>
                  <p className="text-[10px] font-bold text-slate-800">
                    HOSPITAL REGIONAL &quot;LIC. ADOLFO LÓPEZ MATEOS&quot;
                  </p>
                  <p className="text-[10px] text-slate-700">DIRECCIÓN</p>
                  <p className="text-[10px] text-slate-700">
                    SUBDIRECCIÓN MÉDICA
                  </p>
                  <p className="text-[10px] font-bold text-slate-800">
                    {config.oficio.area_emisora?.toUpperCase() ||
                      "COORDINACIÓN DE GINECOLOGÍA Y OBSTETRICIA"}
                  </p>
                  <p className="mt-2 text-[10px] font-bold text-slate-800">
                    Oficio No.{" "}
                    {config.oficio.numero_oficio?.trim() ||
                      `CGO/____/2026`}
                  </p>
                  <p className="text-[10px] text-slate-700">
                    {config.oficio.fecha_emision?.trim() ||
                      `Ciudad de México, a ${new Date().getDate()} de ${new Date().toLocaleDateString(
                        "es-MX",
                        { month: "long" }
                      )} de ${new Date().getFullYear()}`}
                  </p>
                </div>

                {/* Destinatario: funcionario que atiende la queja */}
                <div className="space-y-0.5 pt-2">
                  <p className="text-[11px] font-bold text-slate-900">
                    {(config.oficio.destinatario_nombre?.trim() ||
                      "LIC. MARÍA DEL ROCÍO PAZ OROPEZA").toUpperCase()}
                  </p>
                  <p className="text-[10px] text-slate-700">
                    {(config.oficio.destinatario_cargo?.trim() ||
                      "COORD. DE ATENCIÓN AL DERECHOHABIENTE").toUpperCase()}
                  </p>
                  <p className="text-[10px] text-slate-700">P R E S E N T E.-</p>
                </div>

                {/* Asunto */}
                <p className="text-[11px] font-bold text-slate-900">
                  ASUNTO:{" "}
                  {config.oficio.asunto?.trim() ||
                    "CONTESTACIÓN A QUEJA"}
                </p>

                {/* Cuerpo de la contestación */}
                <div className="space-y-3 whitespace-pre-wrap break-words text-[12px] leading-relaxed text-foreground">
                  {respuesta}
                </div>

                {/* Firma */}
                <div className="border-t pt-6">
                  <div className="mx-auto w-72 border-t border-slate-500 pt-1 text-center">
                    <p className="text-sm font-semibold text-foreground">
                      {config.oficio.firmante_nombre?.trim() ||
                        config.firmante?.trim() ||
                        "UNIDAD DE ATENCIÓN AL DERECHOHABIENTE"}
                    </p>
                    <p className="text-[10px] text-muted-foreground">
                      {config.oficio.firmante_cargo?.trim() ||
                        config.cargo_firmante?.trim() ||
                        "COORDINADOR DE ATENCIÓN AL DERECHOHABIENTE"}
                    </p>
                  </div>
                </div>

                {/* Pie de página institucional */}
                <div className="flex items-start justify-between gap-2 border-t border-slate-300 pt-2">
                  <div className="flex items-center gap-2">
                    <img
                      src="/footer_ilustracion.png"
                      alt="Ilustración Margarita Maza"
                      className="h-8 w-auto opacity-70"
                    />
                    <p className="text-[8px] italic text-slate-500">
                      {config.oficio.ano_conmemorativo?.trim() ||
                        "2026, año de Margarita Maza"}
                    </p>
                  </div>
                  <p className="max-w-[60%] text-right text-[8px] text-slate-600">
                    {config.oficio.direccion_institucion?.trim() ||
                      "Av. Universidad No. 1321, Col. Axotla, C.P. 01030, alcaldía Álvaro Obregón, CDMX, Tel. (55) 5322-2300"}
                  </p>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="texto" className="mt-3">
            <pre className="max-h-[60vh] overflow-y-auto whitespace-pre-wrap break-words rounded-md bg-muted/40 p-4 text-xs leading-relaxed">
              {respuesta}
            </pre>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
