import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "ContestaQuejas ISSSTE — IA para Respuesta a Quejas de Salud",
  description:
    "Aplicación interactiva que analiza capturas de quejas de salud con IA y genera una contestación oficial fundamentada en la normatividad mexicana e ISSSTE CDMX, exportable a PDF.",
  keywords: [
    "ISSSTE",
    "Quejas",
    "Salud",
    "CDMX",
    "México",
    "IA",
    "CONAMED",
    "Cofepris",
    "Atención médica",
  ],
  authors: [{ name: "Unidad de Atención a Derechohabientes" }],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <SonnerToaster position="top-right" richColors closeButton />
      </body>
    </html>
  );
}
