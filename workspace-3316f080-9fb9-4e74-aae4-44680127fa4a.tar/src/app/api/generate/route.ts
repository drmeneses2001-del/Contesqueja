import { NextRequest, NextResponse } from "next/server";
import ZAI from "z-ai-web-dev-sdk";
import { NORMATIVIDAD_SALUD_MEXICO } from "@/lib/normatividad";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 10;

export type Estilo =
  | "formal_institucional"
  | "empatico_cercano"
  | "tecnic_juridico"
  | "conciso_directo";

export type Tono =
  | "neutral_profesional"
  | "calido_humanizado"
  | "enérgico_decidido"
  | "disculpa_reparador";

export type Tamano = "corto" | "medio" | "extenso";

export type Complejidad =
  | "sencillo_legible"
  | "intermedio"
  | "alta_especializacion_juridica";

interface GenerateRequest {
  analisis: unknown;
  estilo: Estilo;
  tono: Tono;
  tamano: Tamano;
  complejidad: Complejidad;
  sugerencias: string;
  firmante?: string;
  cargo_firmante?: string;
  nombre_paciente?: string;
}

interface Job {
  id: string;
  status: "pending" | "processing" | "done" | "error";
  result?: { respuesta: string; meta: Record<string, unknown> };
  error?: string;
  createdAt: number;
  startedAt?: number;
  finishedAt?: number;
}

const jobs = new Map<string, Job>();
const JOB_TTL_MS = 15 * 60 * 1000;

function cleanupExpiredJobs() {
  const now = Date.now();
  for (const [id, job] of jobs) {
    if (now - job.createdAt > JOB_TTL_MS) jobs.delete(id);
  }
}

const DESC_ESTILO: Record<Estilo, string> = {
  formal_institucional:
    "Estilo oficial de oficio gubernamental: encabezado institucional, saludo formal, despedida institucional, redacción en tercera persona.",
  empatico_cercano:
    "Estilo humano y cercano sin perder formalidad: reconoce la vivencia del usuario, valida su sentir, mantiene la cercanía.",
  tecnic_juridico:
    "Estilo jurídico-burocrático: cita artículos, fundamentos legales y considerandos como en una resolución administrativa.",
  conciso_directo:
    "Estilo directo y al grano: párrafos cortos, sin adornos, mensajes accionables.",
};

const DESC_TONO: Record<Tono, string> = {
  neutral_profesional:
    "Tono ecuánime y objetivo, sin cargar emocionalmente el texto.",
  calido_humanizado:
    "Tono cálido, comprensivo, con expresiones de empatía hacia la persona usuaria.",
  enérgico_decidido:
    "Tono firme que comunica compromiso de actuación inmediata.",
  disculpa_reparador:
    "Tono de disculpa institucional explícita y compromiso de reparación del daño.",
};

const DESC_TAMANO: Record<Tamano, string> = {
  corto: "Máximo 200-300 palabras. Una sola sección: respuesta directa y compromiso. Debe caber en media página.",
  medio:
    "Máximo 400-500 palabras. Estructura: saludo, antecedentes breves, respuesta, compromiso, despedida. TODO debe caber en UNA SOLA PÁGINA tamaño carta.",
  extenso:
    "Máximo 500-600 palabras. Estructura: saludo, antecedentes, hechos, marco normativo, resolución, compromisos, despedida. TODO debe caber en UNA SOLA PÁGINA tamaño carta. (Sin mencionar plazos numéricos.)",
};

const DESC_COMPLEJIDAD: Record<Complejidad, string> = {
  sencillo_legible:
    "Lenguaje claro, frases cortas, sin tecnicismos. Apropiado para cualquier ciudadano.",
  intermedio:
    "Lenguaje profesional con algunos términos administrativos explicados.",
  alta_especializacion_juridica:
    "Lenguaje técnico-jurídico con citas puntuales de artículos, uso de términos como 'fundamento', 'motivo', 'considerando', 'resolutivo'.",
};

function construirSystemPrompt(
  estilo: Estilo,
  tono: Tono,
  tamano: Tamano,
  complejidad: Complejidad
): string {
  return `Eres un redactor experto del Instituto de Seguridad y Servicios Sociales de los Trabajadores del Estado (ISSSTE) en la Ciudad de México, especializado en contestar quejas y sugerencias de personas derechohabientes en materia de salud.

Tu misión es redactar la CONTESTACIÓN oficial a una queja, fundamentada en el marco normativo mexicano de salud, particularmente el aplicable al ISSSTE en la CDMX.

# DIRECTRICES DE REDACCIÓN

## Estilo
${DESC_ESTILO[estilo]}

## Tono
${DESC_TONO[tono]}

## Extensión
${DESC_TAMANO[tamano]}

## Complejidad
${DESC_COMPLEJIDAD[complejidad]}

# REGLAS INNEGOCIABLES

1. **No incluyas encabezado institucional ni datos del oficio**: el PDF se genera con un formato institucional predefinido que ya incluye logos, jerarquía institucional (DIRECCIÓN MÉDICA · HOSPITAL REGIONAL "LIC. ADOLFO LÓPEZ MATEOS" · DIRECCIÓN · SUBDIRECCIÓN MÉDICA · COORDINACIÓN DE GINECOLOGÍA Y OBSTETRICIA), número de oficio, fecha, destinatario y asunto. NO repitas estos elementos en el cuerpo. Comienza directamente con el saludo.
2. **No incluyas firma al final**: la firma se genera automáticamente en el PDF con el nombre y cargo del firmante. Tu respuesta debe terminar con la despedida ("Atentamente" o equivalente) SIN incluir el nombre del firmante.
3. **Saludo inicial**: Inicia con "Estimada paciente [NOMBRE DE LA PACIENTE]:" o "Estimada paciente:" si no hay nombre disponible. Dado que la Coordinación emite respuestas a pacientes ginecológicas u obstétricas, el saludo debe dirigirse SIEMPRE en femenino ("Estimada paciente").
4. **Fundamento normativo**: DEBES citar al menos 2 artículos, normas o leyes aplicables del marco normativo mexicano de salud (Constitución, Ley General de Salud, NOM, Reglamento del ISSSTE, etc.).
5. **NO mencionar el Artículo 33 de la Ley de los Derechos de las Personas Usuarias y Pacientes del ISSSTE**: Queda terminantemente prohibido citar o referirse a este artículo.
6. **NO mencionar plazos de resolución**: No incluyas referencias a "30 días hábiles", "15 días ampliables", "60 días", ni ningún otro plazo numérico de respuesta o resolución administrativa. Tampoco uses frases que comprometan un plazo específico (ej: "en un plazo máximo de 24 horas", "dentro de los próximos 5 días"). Si necesitas referirte a la atención, usa expresiones generales como "a la brevedad", "de manera pronta", "en su oportunidad", sin número.
7. **NO sugerir canalización ni trámites a otras instancias**: Queda TERMINANTEMENTE PROHIBIDO sugerir, recomendar o referir a la paciente a cualquier otra instancia, departamento, coordinación u organismo, ya sea interno del ISSSTE (Contraloría Interna, Defensoría de Usuarios, Unidad de Atención al Derechohabiente, otra coordinación clínica) o externo (CONAMED, Cofepris, CNDH, PROFECO, LOCATEL, Secretaría de Salud, etc.). La contestación debe abordar y resolver la queja exclusivamente dentro del ámbito de la Coordinación de Ginecología y Obstetricia.
8. **NO incluir datos de contacto**: No incluyas números telefónicos, correos electrónicos, páginas web, extensiones, direcciones físicas ni ningún otro dato de contacto en el cuerpo de la contestación.
9. **FRASES PROHIBIDAS**: No utilices las siguientes frases ni variaciones equivalentes:
   - "Nos comprometemos a mantenerle informado sobre los avances de la gestión de su queja"
   - "Una vez concluida la investigación, le notificaremos los resultados y las medidas que se implementarán en su caso"
   - "Le informamos que su caso ha sido registrado con el número de referencia [FOLIO]"
   - "Se inició un procedimiento administrativo interno" (si menciona investigación, usa "se realizarán las acciones internas correspondientes" sin detallar procedimientos)
   - Cualquier frase que comprometa notificar resultados, dar seguimiento procesal o confirmar registro con folio.
   - "Para cualquier duda puede comunicarse al teléfono...", "acuda a...", "le sugerimos dirigirse a...", "puede acudir a la Unidad de Atención...", "le recomendamos comunicarse con..."
10. **No inventes datos personales**: Si no se proporciona nombre de la paciente, usa "Estimada paciente" sin inventar nombre. Si no hay folio, no lo menciones.
11. **Enfoque en Ginecología y Obstetricia**: La contestación debe enfocarse DIRECTA Y ÚNICAMENTE en los aspectos ginecológicos u obstétricos presentes en la queja. Si la queja menciona hechos de otras áreas (laboratorio, rayos X, citas generales, farmacia, etc.), omítelos y céntrate solo en lo que compete a la Coordinación de Ginecología y Obstetricia.
12. **No incluyas el literal de las normas**: Solo cita el artículo/norma y un resumen breve de su contenido.
13. **No uses Markdown**: Devuelve texto plano con estructura clara (párrafos separados por línea en blanco). Las secciones pueden ir en MAYÚSCULAS para destacarlas.
14. **Idioma**: Español de México.
15. **No agregues notas, comentarios ni explicaciones fuera del documento**: el texto devuelto ES el cuerpo del documento final.
16. **EXTENSIÓN MÁXIMA ESTRICTA**: La contestación completa (incluyendo saludo y despedida) NO debe exceder 500 palabras. Todo el documento debe caber en UNA SOLA PÁGINA tamaño carta junto con el encabezado institucional, el bloque del oficio, el destinatario, el asunto, la firma y el pie de página. Si tu redacción excede este límite, condensa los párrafos manteniendo los puntos esenciales: saludo, disculpa/reconocimiento, fundamento normativo (1-2 artículos), acciones a realizar, despedida. EVITA repeticiones y desarrollos extensos.

# CONTENIDO PERMITIDO Y RECOMENDADO

- Puedes ofrecer disculpas institucionales por la experiencia vivida.
- Puedes describir las acciones inmediatas que se realizarán para atender la queja (sin plazos numéricos).
- Puedes citar artículos de la Constitución, Ley General de Salud, NOM, Reglamento del ISSSTE (excepto el Art. 33 prohibido).
- Puedes manifestar compromiso institucional de mejora continua.

# MARCO NORMATIVO DE REFERENCIA

${NORMATIVIDAD_SALUD_MEXICO}

# RECORDATORIO FINAL
El texto que devuelvas será el documento que se entregará a la persona usuaria. Debe estar listo para imprimir y firmar. No incluyas markdown, no uses asteriscos, no uses viñetas con guiones largos si puedes evitarlas (usa números o letras cuando enumeres).`;
}

function construirUserPrompt(
  analisis: unknown,
  sugerencias: string,
  firmante?: string,
  cargo_firmante?: string,
  nombrePaciente?: string
): string {
  const a = (analisis as Record<string, unknown>) ?? {};
  const resumen = (a.resumen as Record<string, unknown>) ?? {};
  const clasif = (a.clasificacion as Record<string, unknown>) ?? {};
  const hechos = Array.isArray(a.hechos_clave) ? a.hechos_clave : [];
  const normas = Array.isArray(a.normas_potencialmente_aplicables)
    ? a.normas_potencialmente_aplicables
    : [];

  // Determinar el nombre a usar en el saludo
  const nombre =
    nombrePaciente && nombrePaciente.trim().length > 0
      ? nombrePaciente.trim()
      : (typeof resumen.datos_usuario === "string" &&
          resumen.datos_usuario.trim() &&
          resumen.datos_usuario.trim().toLowerCase() !== "no especificado"
          ? resumen.datos_usuario.trim()
          : "");

  const saludoPaciente = nombre
    ? `Estimada paciente ${nombre}:`
    : "Estimada paciente:";

  const firmanteLine =
    firmante && firmante.trim().length > 0
      ? `Firmante: ${firmante}${
          cargo_firmante && cargo_firmante.trim().length > 0
            ? ` (${cargo_firmante})`
            : ""
        }`
      : "Firmante: Coordinación de Ginecología y Obstetricia";

  return `# QUEJA A CONTESTAR

A continuación se presenta el análisis estructurado de la queja (extraído de las capturas de pantalla enviadas por la paciente):

- Nombre de la paciente: ${nombre || "No especificado (usar 'Estimada paciente:' sin nombre)"}
- Motivo: ${resumen.motivo_queja ?? "No especificado"}
- Institución mencionada: ${
    resumen.institucion_mencionada ?? "No especificada"
  }
- Fecha de los hechos: ${resumen.fecha_hechos ?? "No especificada"}
- Lugar de los hechos: ${resumen.lugar_hechos ?? "No especificado"}
- Folio de la queja: ${resumen.folio_queja ?? "No especificado"}
- Área responsable: ${resumen.area_responsable ?? "No especificada"}
- Clasificación de la queja: ${clasif.tipo ?? "Otro"}
- Gravedad estimada: ${clasif.gravedad ?? "Media"}
- Urgencia: ${clasif.urgencia ?? "Prioritaria"}

Hechos clave narrados:
${hechos.map((h: unknown, i: number) => `${i + 1}. ${h}`).join("\n")}

Pretensión del usuario: ${a.pretension_usuario ?? "No especificada"}

Normas potencialmente aplicables identificadas:
${normas.map((n: unknown) => `- ${n}`).join("\n")}

Texto íntegro de la queja (referencia):
${a.texto_completo ?? "No disponible"}

# SUGERENCIAS DEL REDACTOR HUMANO
${sugerencias && sugerencias.trim().length > 0 ? sugerencias.trim() : "Sin sugerencias adicionales; aplicar criterios institucionales estándar."}

# INSTRUCCIÓN FINAL
Redacta ahora el CUERPO de la contestación oficial siguiendo TODAS las directrices del sistema.

REGLAS CRÍTICAS:
- NO incluyas encabezado institucional, número de oficio, ni fecha.
- NO incluyas datos del destinatario en bloque (ya están en el oficio).
- NO incluyas firma con nombre al final (termina con "Atentamente,").
- INICIA con el saludo: "${saludoPaciente}"
- TERMINA con "Atentamente," (sin nombre).
- NO incluyas números telefónicos, correos ni datos de contacto.
- NO sugieras tramitar a ninguna otra instancia ni coordinación.
- Enfócate ÚNICAMENTE en los aspectos de Ginecología y Obstetricia.
${firmanteLine}`;
}

async function runGeneration(
  jobId: string,
  payload: GenerateRequest
) {
  const job = jobs.get(jobId);
  if (!job) return;
  job.status = "processing";
  job.startedAt = Date.now();

  const {
    analisis,
    estilo,
    tono,
    tamano,
    complejidad,
    sugerencias,
    firmante,
    cargo_firmante,
    nombre_paciente,
  } = payload;

  const systemPrompt = construirSystemPrompt(estilo, tono, tamano, complejidad);
  const userPrompt = construirUserPrompt(
    analisis,
    sugerencias,
    firmante,
    cargo_firmante,
    nombre_paciente
  );

  const MAX_RETRIES = 3;
  const RETRY_DELAYS_MS = [5000, 10000, 20000];
  let lastError: Error | null = null;

  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    try {
      if (attempt > 0) {
        const delay = RETRY_DELAYS_MS[attempt - 1] ?? 20000;
        await new Promise((r) => setTimeout(r, delay));
      }

      const zai = await ZAI.create();
      const completion = await zai.chat.completions.create({
        messages: [
          { role: "assistant", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        thinking: { type: "disabled" },
      });

      const contenido = completion.choices[0]?.message?.content ?? "";
      if (!contenido.trim()) {
        throw new Error("El modelo devolvió una respuesta vacía.");
      }

      job.result = {
        respuesta: contenido,
        meta: {
          estilo,
          tono,
          tamano,
          complejidad,
          generado_en: new Date().toISOString(),
        },
      };
      job.status = "done";
      job.finishedAt = Date.now();
      return;
    } catch (e) {
      lastError = e instanceof Error ? e : new Error(String(e));
      const errMsg = lastError.message;
      console.error(
        `[generate job ${jobId}] Intento ${attempt + 1}/${MAX_RETRIES + 1} falló:`,
        errMsg
      );

      if (
        errMsg.includes("400") ||
        errMsg.includes("401") ||
        errMsg.includes("403") ||
        errMsg.includes("404")
      ) {
        break;
      }
    }
  }

  job.status = "error";
  job.error =
    lastError?.message ||
    "El servicio de IA no está disponible. Intenta nuevamente en unos minutos.";
  job.finishedAt = Date.now();
}

/**
 * POST /api/generate
 * Inicia la generación en background y devuelve un jobId.
 */
export async function POST(req: NextRequest) {
  cleanupExpiredJobs();

  try {
    const body = (await req.json()) as GenerateRequest;
    if (!body.analisis) {
      return NextResponse.json(
        { error: "Se requiere el análisis previo de la queja." },
        { status: 400 }
      );
    }

    const jobId = `gen_${Date.now()}_${Math.random().toString(36).slice(2, 11)}`;
    const job: Job = {
      id: jobId,
      status: "pending",
      createdAt: Date.now(),
    };
    jobs.set(jobId, job);

    runGeneration(jobId, body).catch((e) => {
      console.error(`[job ${jobId}] Error en background:`, e);
      const j = jobs.get(jobId);
      if (j) {
        j.status = "error";
        j.error = e instanceof Error ? e.message : "Error en background";
        j.finishedAt = Date.now();
      }
    });

    return NextResponse.json({ jobId, status: "pending" });
  } catch (error) {
    console.error("[/api/generate POST] Error:", error);
    const message =
      error instanceof Error ? error.message : "Error desconocido";
    return NextResponse.json(
      { error: "Error al iniciar la generación", detail: message },
      { status: 500 }
    );
  }
}

/**
 * GET /api/generate?id=<jobId>
 */
export async function GET(req: NextRequest) {
  const id = req.nextUrl.searchParams.get("id");
  if (!id) {
    return NextResponse.json(
      { error: "Falta el parámetro 'id'" },
      { status: 400 }
    );
  }

  const job = jobs.get(id);
  if (!job) {
    return NextResponse.json(
      { error: "Trabajo no encontrado o expirado", status: "not_found" },
      { status: 404 }
    );
  }

  const elapsedMs =
    (job.finishedAt ?? Date.now()) - (job.startedAt ?? job.createdAt);

  return NextResponse.json({
    status: job.status,
    result: job.result,
    error: job.error,
    elapsedMs,
  });
}
