import { NextRequest, NextResponse } from "next/server";
import ZAI from "z-ai-web-dev-sdk";

export const runtime = "nodejs";
// El endpoint POST debe responder rápido (inicia el trabajo y devuelve jobId).
// El endpoint GET hace polling del estado.
export const dynamic = "force-dynamic";
export const maxDuration = 10;

interface AnalyzeRequest {
  images: string[]; // base64 data URLs
}

interface AnalysisResult {
  texto_completo?: string;
  resumen?: Record<string, unknown>;
  clasificacion?: Record<string, unknown>;
  hechos_clave?: string[];
  pretension_usuario?: string;
  normas_potencialmente_aplicables?: string[];
  _aviso?: string;
}

interface Job {
  id: string;
  status: "pending" | "processing" | "done" | "error";
  result?: AnalysisResult;
  raw?: string;
  error?: string;
  createdAt: number;
  startedAt?: number;
  finishedAt?: number;
}

// Store en memoria (los jobs se limpian automáticamente después de 15 min)
const jobs = new Map<string, Job>();
const JOB_TTL_MS = 15 * 60 * 1000; // 15 minutos

// Limpieza periódica de jobs expirados
function cleanupExpiredJobs() {
  const now = Date.now();
  for (const [id, job] of jobs) {
    if (now - job.createdAt > JOB_TTL_MS) {
      jobs.delete(id);
    }
  }
}

/**
 * Ejecuta el análisis de IA en background.
 * Esta función corre independientemente de la petición HTTP.
 */
async function runAnalysis(jobId: string, images: string[]) {
  const job = jobs.get(jobId);
  if (!job) return;
  job.status = "processing";
  job.startedAt = Date.now();

  const MAX_RETRIES = 4;
  const RETRY_DELAYS_MS = [5000, 10000, 20000, 30000]; // backoff: 5s, 10s, 20s, 30s

  const content: Array<
    | { type: "text"; text: string }
    | { type: "image_url"; image_url: { url: string } }
  > = [
    {
      type: "text",
      text: `Extrae el texto e información de esta queja de salud (México/ISSSTE). Devuelve SOLO JSON válido, sin markdown:

{
  "texto_completo": "transcripción del texto visible",
  "resumen": {
    "motivo_queja": "motivo en una frase",
    "institucion_mencionada": "ISSSTE/hospital/clínica o 'No especificada'",
    "fecha_hechos": "DD/MM/AAAA o 'No especificada'",
    "lugar_hechos": "unidad médica o 'No especificado'",
    "datos_usuario": "nombre del quejoso o 'No especificado'",
    "folio_queja": "folio o 'No especificado'",
    "area_responsable": "área/departamento o 'No especificada'"
  },
  "clasificacion": {
    "tipo": "Atención médica | Medicamentos | Trato del personal | Infraestructura | Trámites administrativos | Cobros | Expediente clínico | Citas | Otro",
    "gravedad": "Alta | Media | Baja",
    "urgencia": "Inmediata | Prioritaria | Programable"
  },
  "hechos_clave": ["3-5 puntos relevantes"],
  "pretension_usuario": "lo que solicita o 'No especificada'",
  "normas_potencialmente_aplicables": ["2-3 normas aplicables"]
}

Si un dato no aparece, usa "No especificado" o []. No inventes.`,
    },
    ...images.map((url) => ({
      type: "image_url" as const,
      image_url: { url },
    })),
  ];

  let lastError: Error | null = null;

  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    try {
      if (attempt > 0) {
        // Esperar antes de reintentar (backoff exponencial)
        const delay = RETRY_DELAYS_MS[attempt - 1] ?? 30000;
        await new Promise((r) => setTimeout(r, delay));
      }

      const zai = await ZAI.create();
      const response = await zai.chat.completions.createVision({
        messages: [{ role: "user", content }],
        thinking: { type: "disabled" },
      });

      const raw = response.choices[0]?.message?.content ?? "";

      let parsed: AnalysisResult;
      try {
        const cleaned = raw
          .replace(/^```json\s*/i, "")
          .replace(/^```\s*/i, "")
          .replace(/```\s*$/i, "")
          .trim();
        parsed = JSON.parse(cleaned);
      } catch {
        parsed = {
          texto_completo: raw,
          _aviso:
            "No se pudo estructurar la respuesta como JSON. Se devuelve el texto crudo.",
        };
      }

      job.result = parsed;
      job.raw = raw;
      job.status = "done";
      job.finishedAt = Date.now();
      return; // éxito
    } catch (e) {
      lastError = e instanceof Error ? e : new Error(String(e));
      const errMsg = lastError.message;
      console.error(
        `[analyze job ${jobId}] Intento ${attempt + 1}/${MAX_RETRIES + 1} falló:`,
        errMsg
      );

      // Si es un error que no vale la pena reintentar, salir del loop
      if (
        errMsg.includes("400") ||
        errMsg.includes("401") ||
        errMsg.includes("403") ||
        errMsg.includes("404")
      ) {
        break;
      }
      // Para 502, 503, 504, timeout, network -> reintentar
    }
  }

  // Todos los intentos fallaron
  job.status = "error";
  job.error =
    lastError?.message ||
    "El servicio de IA no está disponible en este momento. Intenta nuevamente en unos minutos.";
  job.finishedAt = Date.now();
}

/**
 * POST /api/analyze
 * Inicia el análisis en background y devuelve inmediatamente un jobId.
 * El cliente debe hacer polling a GET /api/analyze?id=<jobId> para obtener el resultado.
 */
export async function POST(req: NextRequest) {
  cleanupExpiredJobs();

  try {
    const body = (await req.json()) as AnalyzeRequest;
    const { images } = body;

    if (!images || !Array.isArray(images) || images.length === 0) {
      return NextResponse.json(
        { error: "Se requiere al menos una imagen." },
        { status: 400 }
      );
    }

    const jobId = `job_${Date.now()}_${Math.random().toString(36).slice(2, 11)}`;
    const job: Job = {
      id: jobId,
      status: "pending",
      createdAt: Date.now(),
    };
    jobs.set(jobId, job);

    // Iniciar el análisis en background (no await)
    runAnalysis(jobId, images).catch((e) => {
      console.error(`[job ${jobId}] Error en background:`, e);
      const j = jobs.get(jobId);
      if (j) {
        j.status = "error";
        j.error = e instanceof Error ? e.message : "Error en background";
        j.finishedAt = Date.now();
      }
    });

    return NextResponse.json({ jobId, status: "pending" });
  } catch (error) {
    console.error("[/api/analyze POST] Error:", error);
    const message =
      error instanceof Error ? error.message : "Error desconocido";
    return NextResponse.json(
      { error: "Error al iniciar el análisis", detail: message },
      { status: 500 }
    );
  }
}

/**
 * GET /api/analyze?id=<jobId>
 * Consulta el estado de un trabajo de análisis.
 * Devuelve: { status, result?, error?, elapsedMs? }
 */
export async function GET(req: NextRequest) {
  const id = req.nextUrl.searchParams.get("id");
  if (!id) {
    return NextResponse.json(
      { error: "Falta el parámetro 'id'" },
      { status: 400 }
    );
  }

  const job = jobs.get(id);
  if (!job) {
    return NextResponse.json(
      { error: "Trabajo no encontrado o expirado", status: "not_found" },
      { status: 404 }
    );
  }

  const elapsedMs =
    (job.finishedAt ?? Date.now()) - (job.startedAt ?? job.createdAt);

  return NextResponse.json({
    status: job.status,
    result: job.result,
    raw: job.raw,
    error: job.error,
    elapsedMs,
  });
}
