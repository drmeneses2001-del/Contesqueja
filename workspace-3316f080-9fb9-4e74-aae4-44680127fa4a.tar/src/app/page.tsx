import { QuejaApp } from "@/components/app/queja-app";
import { ShieldCheck, Scale, HeartPulse, FileCheck } from "lucide-react";

export default function Home() {
  return (
    <main className="min-h-screen flex flex-col bg-gradient-to-b from-rose-50/40 via-background to-background">
      {/* Header institucional */}
      <header className="border-b border-border bg-white/80 backdrop-blur supports-[backdrop-filter]:bg-white/60 sticky top-0 z-30">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-3 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-rose-700 to-red-800 text-white shadow-sm">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <div>
              <h1 className="text-sm font-bold leading-tight text-foreground sm:text-base">
                ContestaQuejas · ISSSTE CDMX
              </h1>
              <p className="text-[11px] text-muted-foreground">
                Respuestas a quejas de salud con IA · Fundamentadas en
                normatividad mexicana
              </p>
            </div>
          </div>
          <div className="hidden items-center gap-3 text-[11px] text-muted-foreground sm:flex">
            <span className="flex items-center gap-1">
              <Scale className="h-3.5 w-3.5" /> Ley General de Salud
            </span>
            <span className="flex items-center gap-1">
              <HeartPulse className="h-3.5 w-3.5" /> Ley ISSSTE
            </span>
            <span className="flex items-center gap-1">
              <FileCheck className="h-3.5 w-3.5" /> NOM-024-SSA3-2012
            </span>
          </div>
        </div>
      </header>

      {/* Contenido principal */}
      <div className="mx-auto w-full max-w-6xl flex-1 px-4 py-6 sm:px-6 sm:py-8">
        <section className="mb-6">
          <h2 className="text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
            Convierte una queja en una contestación oficial
          </h2>
          <p className="mt-1 max-w-3xl text-sm text-muted-foreground sm:text-base">
            Sube las capturas de la queja, deja que la IA interprete el
            contenido, configura el estilo de la respuesta (tono, extensión y
            complejidad), añade tus sugerencias y exporta el documento final en
            PDF con encabezado institucional y referencias normativas.
          </p>
        </section>

        <QuejaApp />
      </div>

      {/* Footer */}
      <footer className="mt-auto border-t border-border bg-white/60">
        <div className="mx-auto max-w-6xl px-4 py-4 text-center sm:px-6">
          <p className="text-[11px] text-muted-foreground">
            Herramienta de apoyo para la redacción de contestaciones · La
            respuesta generada debe ser revisada por personal autorizado antes
            de su entrega oficial · No sustituye el criterio jurídico
            institucional.
          </p>
          <p className="mt-1 text-[11px] text-muted-foreground">
            © {new Date().getFullYear()} · Unidad de Atención a
            Derechohabientes, ISSSTE CDMX
          </p>
        </div>
      </footer>
    </main>
  );
}
