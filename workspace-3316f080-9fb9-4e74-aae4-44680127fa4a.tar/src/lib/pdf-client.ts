"use client";

import { jsPDF } from "jspdf";

export interface PdfMeta {
  estilo: string;
  tono: string;
  tamano: string;
  complejidad: string;
  generado_en: string;
}

export interface PdfAnalisisMeta {
  motivo_queja?: string;
  institucion_mencionada?: string;
  fecha_hechos?: string;
  lugar_hechos?: string;
  datos_usuario?: string;
  folio_queja?: string;
  area_responsable?: string;
  tipo?: string;
  gravedad?: string;
  urgencia?: string;
}

export interface PdfOficioData {
  numero_oficio?: string;
  area_emisora?: string;
  area_emisora_superior?: string;
  destinatario_nombre?: string;
  destinatario_cargo?: string;
  asunto?: string;
  fecha_emision?: string;
  firmante_nombre?: string;
  firmante_cargo?: string;
  ano_conmemorativo?: string;
  direccion_institucion?: string;
  nombre_paciente?: string;
}

/**
 * Genera un PDF con el formato institucional del
 * Hospital Regional "Lic. Adolfo López Mateos" del ISSSTE.
 *
 * RESTRICCIÓN CRÍTICA: TODO el contenido debe caber en UNA SOLA PÁGINA
 * tamaño carta. Para lograrlo, se ajusta automáticamente el tamaño de
 * fuente del cuerpo según la longitud del texto.
 */
export function generarPdfRespuesta(
  textoRespuesta: string,
  analisis: PdfAnalisisMeta | undefined,
  meta: PdfMeta,
  opciones?: {
    firmante?: string;
    cargoFirmante?: string;
    oficio?: PdfOficioData;
  }
): jsPDF {
  const doc = new jsPDF({ unit: "pt", format: "letter" });
  const pageWidth = doc.internal.pageSize.getWidth(); // 612pt
  const pageHeight = doc.internal.pageSize.getHeight(); // 792pt
  const margin = 45;
  const maxWidth = pageWidth - margin * 2;

  const oficio = opciones?.oficio ?? {};

  // ============================================================
  // PASO 1: Pre-calcular todas las dimensiones fijas (encabezado,
  // bloque institucional, destinatario, asunto, firma y pie).
  // Estas NO cambian según el tamaño de fuente del cuerpo.
  // ============================================================

  // --- Encabezado (logos + línea separadora) ---
  const headerEndY = 110; // después de la línea separadora

  // --- Bloque institucional (5 líneas + oficio + fecha) ---
  const lineasInstitucion = [
    "DIRECCIÓN MÉDICA",
    'HOSPITAL REGIONAL "LIC. ADOLFO LÓPEZ MATEOS"',
    "DIRECCIÓN",
    "SUBDIRECCIÓN MÉDICA",
    (oficio.area_emisora?.trim() || "COORDINACIÓN DE GINECOLOGÍA Y OBSTETRICIA").toUpperCase(),
  ];
  // Cada línea ~12pt + gap + oficio + fecha (1-2 líneas)
  const bloqueInstitucionalHeight = lineasInstitucion.length * 12 + 6 + 14 + 24; // ~104pt

  // --- Destinatario (3 líneas) ---
  const destinatarioHeight = 13 + 13 + 13 + 18; // nombre + cargo + presente + gap

  // --- Asunto (1 línea, puede envolver) ---
  const asunto =
    oficio.asunto?.trim() ||
    (analisis?.motivo_queja
      ? `CONTESTACIÓN A QUEJA. ${analisis.motivo_queja}`
      : "CONTESTACIÓN A QUEJA");
  const asuntoText = `ASUNTO: ${asunto}`;
  // Estimar 1-2 líneas para el asunto
  const asuntoHeight = 24; // conservador: 1-2 líneas

  // --- Firma (línea + nombre + cargo) ---
  const firmante =
    opciones?.firmante?.trim() ||
    oficio.firmante_nombre?.trim() ||
    "UNIDAD DE ATENCIÓN AL DERECHOHABIENTE";
  const cargoFirmante =
    opciones?.cargoFirmante?.trim() ||
    oficio.firmante_cargo?.trim() ||
    "COORDINADOR DE ATENCIÓN AL DERECHOHABIENTE";
  const firmaHeight = 30 + 13 + 12 + 22; // gap + línea + nombre + cargo + buffer

  // --- Pie de página ---
  const footerHeight = 70; // ilustración + línea + dirección + meta

  // --- Espacio total fijo (no cuerpo) ---
  const fixedHeight =
    headerEndY +
    bloqueInstitucionalHeight +
    destinatarioHeight +
    asuntoHeight +
    firmaHeight +
    footerHeight;

  // Espacio disponible para el cuerpo
  const availableBodyHeight = pageHeight - fixedHeight;
  // availableBodyHeight ~ 792 - 110 - 104 - 57 - 24 - 77 - 70 = ~350pt

  // ============================================================
  // PASO 2: Determinar el tamaño de fuente óptimo para que el
  // cuerpo del texto quepa en el espacio disponible.
  // Probamos tamaños de 11pt hacia abajo hasta que encaje.
  // ============================================================

  const parrafos = textoRespuesta
    .split(/\n\s*\n/)
    .map((p) => p.trim())
    .filter((p) => p.length > 0);

  let bodyFontSize = 10.5;
  let bodyLineHeight = 14;
  let bodyParagraphGap = 5;
  let totalBodyHeight = 0;
  let bodyLines: string[] = [];

  const TAMANOS_FUENTE = [10.5, 10, 9.5, 9, 8.5, 8, 7.5, 7, 6.5, 6];

  for (const size of TAMANOS_FUENTE) {
    bodyFontSize = size;
    bodyLineHeight = size * 1.32;
    bodyParagraphGap = Math.max(3, size * 0.45);

    doc.setFont("helvetica", "normal");
    doc.setFontSize(bodyFontSize);

    // Calcular líneas necesarias para cada párrafo
    bodyLines = [];
    for (const parrafo of parrafos) {
      const lines = doc.splitTextToSize(parrafo, maxWidth);
      bodyLines.push(...lines);
      bodyLines.push(""); // gap entre párrafos
    }

    // Altura total = (n_lines * lineHeight) + (n_parrafos * gap)
    // Aproximación: cada línea ocupa lineHeight, los gaps ya están como líneas vacías
    totalBodyHeight = bodyLines.length * bodyLineHeight;

    if (totalBodyHeight <= availableBodyHeight) {
      break; // este tamaño cabe
    }
  }

  // Si aún con la fuente más pequeña no cabe, truncar el contenido
  // (manteniendo las primeras líneas y "Atentamente,")
  if (totalBodyHeight > availableBodyHeight) {
    // Recalcular cuántas líneas caben realmente
    const maxLines = Math.floor(availableBodyHeight / bodyLineHeight);
    // Conservar las primeras maxLines-1 líneas + "Atentamente,"
    const atentamenteIdx = bodyLines.findIndex((l) =>
      l.toLowerCase().includes("atentamente")
    );
    if (atentamenteIdx >= 0 && atentamenteIdx < maxLines) {
      bodyLines = bodyLines.slice(0, Math.max(maxLines, atentamenteIdx + 1));
    } else {
      bodyLines = bodyLines.slice(0, maxLines - 1);
      // Asegurar que termine con "Atentamente,"
      if (!bodyLines.some((l) => l.toLowerCase().includes("atentamente"))) {
        bodyLines.push("");
        bodyLines.push("Atentamente,");
      }
    }
  }

  // ============================================================
  // PASO 3: Dibujar el documento
  // ============================================================

  // --- ENCABEZADO INSTITUCIONAL ---
  try {
    doc.addImage("/header_logos.png", "PNG", margin, 28, 220, 56);
  } catch (e) {
    console.warn("No se pudo cargar header_logos.png", e);
  }
  try {
    doc.addImage(
      "/header_ilustracion.png",
      "PNG",
      pageWidth - margin - 55,
      26,
      52,
      62
    );
  } catch (e) {
    console.warn("No se pudo cargar header_ilustracion.png", e);
  }

  // Línea separadora del encabezado
  let cursorY = headerEndY - 10;
  doc.setDrawColor(120, 120, 120);
  doc.setLineWidth(0.6);
  doc.line(margin, cursorY, pageWidth - margin, cursorY);
  cursorY = headerEndY;

  // --- BLOQUE INSTITUCIONAL (derecha) ---
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8.5);
  doc.setTextColor(20, 20, 20);
  for (const linea of lineasInstitucion) {
    doc.text(linea, pageWidth - margin, cursorY, { align: "right" });
    cursorY += 11.5;
  }

  cursorY += 4;
  // Oficio No.
  const numeroOficio =
    oficio.numero_oficio?.trim() ||
    `CGO/${(analisis?.folio_queja || "").replace(/\s/g, "").slice(-6) || "000"}/2026`;
  doc.setFontSize(8.5);
  doc.setFont("helvetica", "bold");
  doc.text(`Oficio No. ${numeroOficio}`, pageWidth - margin, cursorY, {
    align: "right",
  });
  cursorY += 13;

  // Fecha de emisión
  const fechaEmision =
    oficio.fecha_emision?.trim() ||
    `Ciudad de México, a ${new Date().getDate()} de ${new Date().toLocaleDateString(
      "es-MX",
      { month: "long" }
    )} de ${new Date().getFullYear()}`;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8.5);
  doc.setTextColor(40, 40, 40);
  const fechaLines = doc.splitTextToSize(fechaEmision, 220);
  for (const fl of fechaLines) {
    doc.text(fl, pageWidth - margin, cursorY, { align: "right" });
    cursorY += 11.5;
  }

  cursorY += 16;

  // --- DESTINATARIO (izquierda) ---
  // El destinatario es el FUNCIONARIO que atiende la queja (ej. Coord. de
  // Atención al Derechohabiente), NO la paciente. La paciente aparece solo
  // en el saludo del cuerpo del documento.
  const destNombre =
    oficio.destinatario_nombre?.trim() ||
    "LIC. MARÍA DEL ROCÍO PAZ OROPEZA";
  const destCargo =
    oficio.destinatario_cargo?.trim() ||
    "COORD. DE ATENCIÓN AL DERECHOHABIENTE";

  doc.setFont("helvetica", "bold");
  doc.setFontSize(9.5);
  doc.setTextColor(20, 20, 20);
  doc.text(destNombre.toUpperCase(), margin, cursorY);
  cursorY += 12;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8.5);
  doc.setTextColor(60, 60, 60);
  doc.text(destCargo.toUpperCase(), margin, cursorY);
  cursorY += 12;
  doc.text("P R E S E N T E.-", margin, cursorY);
  cursorY += 18;

  // --- ASUNTO ---
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.setTextColor(20, 20, 20);
  const asuntoLines = doc.splitTextToSize(asuntoText, maxWidth);
  for (const al of asuntoLines) {
    doc.text(al, margin, cursorY);
    cursorY += 12;
  }
  cursorY += 8;

  // --- CUERPO DE LA RESPUESTA ---
  doc.setFont("helvetica", "normal");
  doc.setFontSize(bodyFontSize);
  doc.setTextColor(30, 30, 30);

  for (const linea of bodyLines) {
    if (linea === "") {
      cursorY += bodyParagraphGap;
    } else {
      doc.text(linea, margin, cursorY, {
        align: "justify",
        maxWidth: maxWidth,
      });
      cursorY += bodyLineHeight;
    }
  }

  // --- FIRMA ---
  cursorY += 18;

  // Línea de firma
  doc.setDrawColor(80, 80, 80);
  doc.setLineWidth(0.5);
  doc.line(pageWidth / 2 - 110, cursorY, pageWidth / 2 + 110, cursorY);
  cursorY += 12;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.setTextColor(20, 20, 20);
  doc.text(firmante, pageWidth / 2, cursorY, { align: "center" });
  cursorY += 11;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.setTextColor(80, 80, 80);
  const cargoLines = doc.splitTextToSize(cargoFirmante, 220);
  for (const cl of cargoLines) {
    doc.text(cl, pageWidth / 2, cursorY, { align: "center" });
    cursorY += 10;
  }

  // --- PIE DE PÁGINA ---
  addFooter(doc, pageWidth, pageHeight, margin, oficio, meta);

  return doc;
}

/**
 * Dibuja el pie de página institucional.
 */
function addFooter(
  doc: jsPDF,
  pageWidth: number,
  pageHeight: number,
  margin: number,
  oficio: PdfOficioData,
  meta: PdfMeta
) {
  const footerY = pageHeight - 55;

  // Ilustración izquierda
  try {
    doc.addImage(
      "/footer_ilustracion.png",
      "PNG",
      margin,
      footerY - 22,
      30,
      30
    );
  } catch (e) {
    console.warn("No se pudo cargar footer_ilustracion.png", e);
  }

  // Texto "año de Margarita Maza"
  const anoTexto =
    oficio.ano_conmemorativo?.trim() || "2026, año de Margarita Maza";
  doc.setFont("helvetica", "italic");
  doc.setFontSize(7);
  doc.setTextColor(110, 110, 110);
  const anoLines = doc.splitTextToSize(anoTexto, 85);
  let ty = footerY + 12;
  for (const al of anoLines) {
    doc.text(al, margin + 15, ty, { align: "center" });
    ty += 8;
  }

  // Línea separadora del pie
  doc.setDrawColor(150, 150, 150);
  doc.setLineWidth(0.4);
  doc.line(margin, footerY - 5, pageWidth - margin, footerY - 5);

  // Dirección del hospital (centro/derecha)
  const direccion =
    oficio.direccion_institucion?.trim() ||
    'Av. Universidad No. 1321, Col. Axotla, C.P. 01030, alcaldía Álvaro Obregón, CDMX, Tel. (55) 5322-2300';
  doc.setFont("helvetica", "normal");
  doc.setFontSize(7);
  doc.setTextColor(80, 80, 80);
  const dirLines = doc.splitTextToSize(direccion, pageWidth - margin * 2 - 100);
  let dy = footerY + 3;
  for (const dl of dirLines) {
    doc.text(dl, pageWidth / 2 + 35, dy, { align: "center" });
    dy += 8;
  }

  // Línea inferior con metadatos (muy sutil)
  doc.setFont("helvetica", "normal");
  doc.setFontSize(6);
  doc.setTextColor(170, 170, 170);
  const fechaGen = new Date(meta.generado_en).toLocaleString("es-MX", {
    dateStyle: "short",
    timeStyle: "short",
  });
  doc.text(
    `Generado el ${fechaGen} · Estilo: ${meta.estilo.replace(/_/g, " ")} · Tono: ${meta.tono.replace(/_/g, " ")} · Complejidad: ${meta.complejidad.replace(/_/g, " ")}`,
    margin,
    pageHeight - 15
  );
}

export function descargarPdf(
  textoRespuesta: string,
  analisis: PdfAnalisisMeta | undefined,
  meta: PdfMeta,
  opciones?: {
    firmante?: string;
    cargoFirmante?: string;
    oficio?: PdfOficioData;
    nombreArchivo?: string;
  }
) {
  const doc = generarPdfRespuesta(textoRespuesta, analisis, meta, opciones);
  const nombre =
    opciones?.nombreArchivo?.trim() ||
    `contestacion_queja_${new Date().toISOString().slice(0, 10)}.pdf`;
  doc.save(nombre);
}
