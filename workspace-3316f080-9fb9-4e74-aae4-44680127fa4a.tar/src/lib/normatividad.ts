/**
 * Base de conocimiento normativo para respuestas a quejas de salud
 * en la República Mexicana e ISSSTE en la CDMX.
 *
 * Este contenido se inyecta en el prompt del LLM para fundamentar
 * jurídicamente las respuestas.
 *
 * NOTA: La unidad emisora es la Coordinación de Ginecología y Obstetricia
 * del Hospital Regional "Lic. Adolfo López Mateos" del ISSSTE.
 */

export const NORMATIVIDAD_SALUD_MEXICO = `
## ÁMBITO DE COMPETENCIA: COORDINACIÓN DE GINECOLOGÍA Y OBSTETRICIA

Esta Coordinación pertenece a la Subdirección Médica del Hospital Regional "Lic. Adolfo López Mateos" del ISSSTE. Su competencia abarca EXCLUSIVAMENTE:

- Atención ginecológica (consulta externa, patología cervical, colposcopia, histeroscopia, ecoografía ginecológica).
- Atención obstétrica (control prenatal, atención del parto, puerperio, embarazo de alto riesgo).
- Cirugía ginecológica (histerectomías, laparoscopia, tratamiento de miomatosis, endometriosis, etc.).
- Planificación familiar (métodos anticonceptivos, ligadura tubaria, DIU).
- Detección oportuna de cáncer cérvico-uterino y mamario.
- Atención de urgencias gineco-obstétricas.
- Hospitalización y sala de expulsión.
- Residentes de la especialidad en formación.

SERVICIOS QUE NO SON DE LA COMPETENCIA DE ESTA COORDINACIÓN (no abordarlos en la contestación):
- Laboratorio clínico o banco de sangre.
- Rayos X, ultrasonido general (excepto el ginecológico), tomografía, resonancia.
- Citas de otras especialidades (Cardiología, Medicina Interna, Cirugía General, etc.).
- Farmacia y abasto de medicamentos en general.
- Expediente clínico de otras áreas.
- Trámites administrativos de otras áreas (afiliación, cobranza, pensiones, etc.).
- Atención de pacientes no relacionados con ginecología u obstetricia.

REGLA FUNDAMENTAL: La contestación debe enfocarse DIRECTA Y ÚNICAMENTE en los aspectos ginecológicos u obstétricos presentes en la queja. Si la queja menciona hechos de otras áreas (laboratorio, rayos X, citas generales, etc.), la contestación debe acotarse a los puntos que competen a Ginecología y Obstetricia y omitir el resto.

## MARCO NORMATIVO APLICABLE

### 1. Constitución Política de los Estados Unidos Mexicanos
- **Artículo 4**: Toda persona tiene derecho a la protección de la salud. La Ley definirá las bases y modalidades para el acceso a los servicios de salud y establecerá la concurrencia de la Federación y las entidades federativas en materia de salubridad general.
- **Artículo 1**: Obligación del Estado de garantizar los derechos humanos, principio pro persona y control de convencionalidad.

### 2. Ley General de Salud (LGS)
- **Artículo 6**: El Sistema Nacional de Salud tiene como objetivos el cumplimiento del derecho a la protección de la salud.
- **Artículo 32**: Se otorgan servicios de salud a través de instituciones públicas, sociales y privadas.
- **Artículo 51**: Los usuarios tendrán derecho a recibir servicios de salud oportunos y de calidad.
- **Artículo 72**: Los pacientes tienen derecho a recibir información adecuada sobre su estado de salud.
- **Artículo 73**: Los pacientes tienen derecho a dar su consentimiento informado.
- **Artículo 91-Bis**: Servicios de Atención Médica.
- **Artículo 417**: Las violaciones a esta Ley serán sancionadas por las autoridades sanitarias.
- **Título Décimo Quinto** (Artículos 416-462): Infracciones y sanciones, quejas y procedimientos.

### 3. Ley de los Derechos de las Personas Usuarias y Pacientes del ISSSTE
- **Artículo 2**: Las disposiciones son de orden público e interés social.
- **Artículo 4**: Toda persona usuaria o paciente del ISSSTE tiene derecho a la protección de la salud.
- **Artículo 5**: Derechos de los usuarios: trato digno, información veraz, atención médica oportuna, expediente clínico, consentimiento informado, segunda opinión, entre otros.
- **Artículo 7**: Derecho a presentar quejas y denuncias.
- **Artículo 14**: Derecho a recibir información completa sobre diagnósticos, pronósticos y procedimientos.
- **Artículo 21**: Derecho a un expediente clínico completo y legible.
- (NOTA: No citar el Artículo 33 de esta Ley. Existe pero está prohibido mencionarlo en las contestaciones.)

### 4. Reglamento de la Ley de los Derechos de las Personas Usuarias y Pacientes del ISSSTE
- Establece disposiciones para el trámite de quejas dentro del ISSSTE.
- (No mencionar plazos numéricos ni instancias externas en las contestaciones.)

### 5. NOM-024-SSA3-2012
Sistema de información de expediente clínico electrónico.
- Establece los criterios para el expediente clínico electrónico.
- Derecho del paciente a acceder a su información clínica.

### 6. NOM-004-SSA3-2012
Del expediente clínico.
- **Artículo 13**: Contenido mínimo del expediente clínico.
- **Artículo 41**: Derecho del paciente a obtener copia de su expediente.

### 7. NOM-178-SSA1-1998
Que establece los requisitos mínimos de infraestructura y equipamiento de establecimientos para la atención médica de pacientes ambulatorios.

### 8. Ley Federal de Procedimiento Administrativo (LFPA)
- **Artículo 6**: Derecho a presentar promociones, solicitudes o quejas.
- (No mencionar plazos numéricos en las contestaciones.)

### 9. Reglamento Interior del ISSSTE
- Competencias de las unidades administrativas para atender quejas.

### 10. Norma Oficial Mexicana NOM-253-SSA1-2012
Para la disposición de sangre humana y sus componentes con fines terapéuticos.

## TIPOS DE QUEJAS MÁS FRECUENTES EN ISSSTE
1. Negativa o demora en la atención médica.
2. Maltrato por parte del personal médico o administrativo.
3. Falta de medicamentos en farmacia del ISSSTE.
4. Cobros indebidos por servicios.
5. Demora en citas y consultas especializadas.
6. Negativa de expediente clínico.
7. Mala praxis médica.
8. Condiciones deficientes en hospitales.
9. Falta de consentimiento informado.
10. Negativa de referencias a especialistas.

## CANALES DE CONTACTO DEL ISSSTE
- **Unidad de Atención al Derechohabiente**: Atención directa dentro del ISSSTE.
- (IMPORTANTE: NO incluir números telefónicos ni datos de contacto en las contestaciones. Tampoco sugerir acudir a otras instancias.)

## IMPORTANTE: RESTRICCIONES DE REDACCIÓN
- NO citar el Artículo 33 de la Ley de los Derechos de las Personas Usuarias y Pacientes del ISSSTE.
- NO mencionar plazos numéricos (30 días, 15 días, 60 días, etc.).
- NO sugerir canalización a CONAMED, Cofepris, CNDH, Contraloría Interna, Defensoría ni ninguna otra instancia externa al ISSSTE.
- NO usar frases que comprometan notificar resultados o confirmar folio de registro.
- NO incluir números telefónicos, correos electrónicos, páginas web ni ningún dato de contacto en el cuerpo de la contestación.
- NO sugerir tramitar o acudir a ninguna otra instancia, departamento o coordinación distinta a la Coordinación de Ginecología y Obstetricia.
`;

