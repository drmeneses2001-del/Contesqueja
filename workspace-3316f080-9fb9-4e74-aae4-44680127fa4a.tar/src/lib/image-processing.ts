/**
 * Utilidades para preprocesar imágenes en el cliente antes de enviarlas
 * al endpoint de análisis:
 *
 *  - Corregir orientación EXIF (frecuente en fotos de iPhone/Android)
 *  - Redimensionar a un tamaño máximo (evita payloads enormes)
 *  - Comprimir a JPEG con calidad controlada
 *  - Devolver un data URL listo para enviar
 */

interface ProcessOptions {
  maxDimension?: number; // tamaño máximo del lado más largo, en px
  quality?: number; // calidad JPEG 0..1
  mimeType?: string; // mime de salida
}

const DEFAULTS: Required<ProcessOptions> = {
  maxDimension: 2000,
  quality: 0.85,
  mimeType: "image/jpeg",
};

/**
 * Lee la orientación EXIF de un archivo JPEG.
 * Devuelve el valor de orientación (1-8) o 1 si no se encuentra.
 * Fuente: EXIF Orientation tag (0x0112).
 */
function readExifOrientation(file: File): Promise<number> {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const view = new DataView(reader.result as ArrayBuffer);
        if (view.byteLength < 2 || view.getUint16(0, false) !== 0xffd8) {
          resolve(1);
          return;
        }
        let offset = 2;
        let marker: number;
        while (offset < view.byteLength) {
          marker = view.getUint16(offset, false);
          offset += 2;
          if (marker === 0xffe1) {
            // APP1 (EXIF)
            const exifLength = view.getUint16(offset, false);
            offset += 2;
            if (view.getUint32(offset, false) !== 0x45786966) {
              resolve(1);
              return;
            }
            offset += 6; // "Exif\0\0"
            const tiffOffset = offset;
            const isLittleEndian =
              view.getUint16(tiffOffset, false) === 0x4949;
            const ifdOffset =
              tiffOffset +
              view.getUint32(tiffOffset + 4, isLittleEndian);
            let entries = view.getUint16(ifdOffset, isLittleEndian);
            let entryOffset = ifdOffset + 2;
            while (entries > 0) {
              const tag = view.getUint16(entryOffset, isLittleEndian);
              if (tag === 0x0112) {
                // Orientation
                resolve(
                  view.getUint16(entryOffset + 8, isLittleEndian)
                );
                return;
              }
              entryOffset += 12;
              entries--;
            }
            resolve(1);
            return;
          } else if ((marker & 0xff00) !== 0xff00) {
            break;
          } else {
            offset += view.getUint16(offset, false);
          }
        }
        resolve(1);
      } catch {
        resolve(1);
      }
    };
    reader.onerror = () => resolve(1);
    reader.readAsArrayBuffer(file);
  });
}

/**
 * Calcula la transformación de canvas necesaria para corregir
 * la orientación EXIF.
 */
function applyOrientationFix(
  ctx: CanvasRenderingContext2D,
  img: HTMLImageElement,
  orientation: number,
  width: number,
  height: number
) {
  switch (orientation) {
    case 2:
      ctx.translate(width, 0);
      ctx.scale(-1, 1);
      break;
    case 3:
      ctx.translate(width, height);
      ctx.rotate(Math.PI);
      break;
    case 4:
      ctx.translate(0, height);
      ctx.scale(1, -1);
      break;
    case 5:
      ctx.rotate(0.5 * Math.PI);
      ctx.scale(1, -1);
      break;
    case 6:
      ctx.rotate(0.5 * Math.PI);
      ctx.translate(0, -height);
      break;
    case 7:
      ctx.rotate(0.5 * Math.PI);
      ctx.translate(width, -height);
      ctx.scale(-1, 1);
      break;
    case 8:
      ctx.rotate(-0.5 * Math.PI);
      ctx.translate(-width, 0);
      break;
    default:
      break;
  }
  ctx.drawImage(img, 0, 0, width, height);
}

/**
 * Carga un archivo como HTMLImageElement.
 */
function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = (e) => reject(e);
    img.src = src;
  });
}

/**
 * Preprocesa un archivo de imagen:
 *   1. Lee orientación EXIF
 *   2. Carga la imagen
 *   3. Calcula dimensiones finales respetando maxDimension
 *   4. Dibuja en canvas aplicando corrección de orientación
 *   5. Exporta como JPEG comprimido
 *
 * Devuelve un data URL (data:image/jpeg;base64,...)
 */
export async function processImage(
  file: File,
  opts: ProcessOptions = {}
): Promise<string> {
  const config = { ...DEFAULTS, ...opts };

  // Para PNGs con transparencia o imágenes pequeñas, mantener formato original
  const isJpeg =
    file.type === "image/jpeg" || file.type === "image/jpg";
  const isPng = file.type === "image/png";
  const isWebp = file.type === "image/webp";

  // Leer el archivo como data URL para cargarlo en un <img>
  const objectUrl = URL.createObjectURL(file);
  try {
    const img = await loadImage(objectUrl);

    // Si la imagen ya es pequeña y es JPEG/PNG/WEBP, devolverla tal cual
    const needsResize =
      Math.max(img.width, img.height) > config.maxDimension;

    // Determinar orientación EXIF (solo JPEG)
    const orientation = isJpeg ? await readExifOrientation(file) : 1;
    const needsOrientationFix = orientation > 1 && orientation <= 8;

    // Si no hay nada que hacer, devolver el archivo original como data URL
    if (!needsResize && !needsOrientationFix) {
      return await fileToDataUrl(file);
    }

    // Calcular dimensiones del canvas respetando maxDimension
    let canvasW = img.width;
    let canvasH = img.height;
    if (needsResize) {
      const ratio = config.maxDimension / Math.max(img.width, img.height);
      canvasW = Math.round(img.width * ratio);
      canvasH = Math.round(img.height * ratio);
    }

    // Si la orientación es 5-8, hay que rotar 90°, así que intercambiamos W y H
    const isSideways = orientation >= 5 && orientation <= 8;
    const finalW = isSideways ? canvasH : canvasW;
    const finalH = isSideways ? canvasW : canvasH;

    const canvas = document.createElement("canvas");
    canvas.width = finalW;
    canvas.height = finalH;
    const ctx = canvas.getContext("2d");
    if (!ctx) {
      throw new Error("No se pudo crear el contexto de canvas");
    }

    // Aplicar corrección y dibujar
    ctx.save();
    applyOrientationFix(ctx, img, orientation, canvasW, canvasH);
    ctx.restore();

    // Determinar mime de salida
    let outMime = config.mimeType;
    if (isPng && !needsResize) {
      outMime = "image/png";
    }

    const quality = outMime === "image/png" ? undefined : config.quality;
    return canvas.toDataURL(outMime, quality);
  } finally {
    URL.revokeObjectURL(objectUrl);
  }
}

function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

/**
 * Estima el tamaño en bytes de un data URL (base64).
 */
export function dataUrlSize(dataUrl: string): number {
  const b64 = dataUrl.split(",")[1] ?? "";
  const padding = b64.endsWith("==") ? 2 : b64.endsWith("=") ? 1 : 0;
  return Math.floor((b64.length * 3) / 4) - padding;
}
