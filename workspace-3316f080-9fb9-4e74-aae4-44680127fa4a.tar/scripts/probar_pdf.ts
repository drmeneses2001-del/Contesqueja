/**
 * Script de prueba para generar un PDF de ejemplo en Node
 * y validar visualmente el formato institucional.
 */
import { generarPdfRespuesta } from "../src/lib/pdf-client";
import * as fs from "fs";

const textoRespuesta = `Estimada Ciudadana Derechohabiente:

Recibimos su queja con folio ISSSTE-CDMX-2024-09876, presentada el 15 de junio de 2024, en la que se denuncia la denegación de atención médica en la Clínica Médico Familiar Tláhuac, consultorio 4. Agradecemos su confianza al informarnos sobre este hecho, que ha sido analizado conforme a la normatividad aplicable.

ANTECEDENTES
El día 15 de junio de 2024, aproximadamente a las 09:30 horas, usted acudió al consultorio 4 para solicitar atención médica por un dolor agudo en el pecho que presentaba desde la noche anterior. Según su narración, la médica de turno se negó a proporcionarle la atención requerida argumentando la falta de cita previa, a pesar de la urgencia del caso que usted manifestó.

RESPUESTA
El ISSSTE reconoce el derecho de toda persona a la protección de la salud consagrado en el artículo 4 de la Constitución Política de los Estados Unidos Mexicanos, así como el derecho a recibir servicios de salud oportunos y de calidad previsto en el artículo 51 de la Ley General de Salud. En este sentido, lamentamos profundamente la experiencia que usted refiere y le ofrecemos una disculpa institucional por el trato recibido.

Conforme al artículo 33 de la Ley de los Derechos de las Personas Usuarias y Pacientes del ISSSTE, hemos iniciado un procedimiento administrativo interno para investigar los hechos señalados, el cual será resuelto en un plazo no mayor a 30 días hábiles. Asimismo, se ha agendado una cita prioritaria para su valoración médica en un plazo máximo de 24 horas.

COMPROMISOS
1. Atención médica prioritaria en un plazo no mayor a 24 horas, gestionada a través de la Coordinación de Atención al Derechohabiente.
2. Investigación interna de los hechos descritos, conforme al Reglamento Interior del ISSSTE.
3. Resolución del procedimiento administrativo en un plazo máximo de 30 días hábiles, comunicada por escrito.

Quedamos a su disposición para cualquier aclaración adicional y agradecemos nuevamente su confianza en este Instituto.

Atentamente,`;

const meta = {
  estilo: "formal_institucional",
  tono: "neutral_profesional",
  tamano: "medio",
  complejidad: "intermedio",
  generado_en: new Date().toISOString(),
};

const doc = generarPdfRespuesta(
  textoRespuesta,
  {
    folio_queja: "ISSSTE-CDMX-2024-09876",
    fecha_hechos: "15/06/2024",
    datos_usuario: "Juan Pérez Hernández",
    institucion_mencionada: "ISSSTE - CMF Tláhuac",
    lugar_hechos: "CMF Tláhuac, consultorio 4",
    area_responsable: "Personal médico del CMF Tláhuac",
    motivo_queja: "Denegación de servicio médico",
    tipo: "Atención médica",
    gravedad: "Alta",
    urgencia: "Inmediata",
  },
  meta,
  {
    oficio: {
      numero_oficio: "CGO/1234/2026",
      area_emisora: "COORDINACIÓN DE GINECOLOGÍA Y OBSTETRICIA",
      destinatario_nombre: "LIC. MARÍA DEL ROCÍO PAZ OROPEZA",
      destinatario_cargo: "COORD. DE ATENCIÓN AL DERECHOHABIENTE",
      asunto: "CONTESTACIÓN A QUEJA POR DENEGACIÓN DE SERVICIO MÉDICO",
      fecha_emision: "Ciudad de México, a 7 de julio de 2026",
      firmante_nombre: "DR. ROBERTO MENDOZA GARCÍA",
      firmante_cargo: "COORDINADOR DE GINECOLOGÍA Y OBSTETRICIA",
      ano_conmemorativo: "2026, año de Margarita Maza",
      direccion_institucion:
        "Av. Universidad No. 1321, Col. Axotla, C.P. 01030, alcaldía Álvaro Obregón, CDMX, Tel. (55) 5322-2300",
    },
  }
);

const buffer = doc.output("arraybuffer");
fs.writeFileSync(
  "/home/z/my-project/download/prueba_formato_institucional.pdf",
  Buffer.from(buffer)
);
console.log("PDF de prueba generado: /home/z/my-project/download/prueba_formato_institucional.pdf");
