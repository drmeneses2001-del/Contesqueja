"""
Genera una imagen de prueba con texto simulando una queja de salud al ISSSTE.
"""
from PIL import Image, ImageDraw, ImageFont
import os

W, H = 800, 1100
img = Image.new("RGB", (W, H), "white")
draw = ImageDraw.Draw(img)

def load_font(size):
    for path in [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
        "/usr/share/fonts/truetype/freefont/FreeSans.ttf",
    ]:
        if os.path.exists(path):
            try:
                return ImageFont.truetype(path, size)
            except Exception:
                pass
    return ImageFont.load_default()

title_font = load_font(22)
bold_font = load_font(18)
normal_font = load_font(16)
small_font = load_font(13)

draw.rectangle([20, 20, W-20, H-20], outline="#999999", width=1)

draw.text((40, 40), "INSTITUTO DE SEGURIDAD Y SERVICIOS SOCIALES", fill="#7a1f1f", font=title_font)
draw.text((40, 70), "DE LOS TRABAJADORES DEL ESTADO (ISSSTE)", fill="#7a1f1f", font=title_font)
draw.text((40, 100), "Clinica Medico Familiar Tlahuac", fill="#444", font=bold_font)
draw.line([40, 130, W-40, 130], fill="#7a1f1f", width=2)

draw.text((40, 150), "Folio de queja: ISSSTE-CDMX-2024-09876", fill="#000", font=normal_font)
draw.text((40, 175), "Fecha de los hechos: 15 de junio de 2024", fill="#000", font=normal_font)
draw.text((40, 200), "Lugar: CMF Tlahuac, consultorio 4", fill="#000", font=normal_font)
draw.text((40, 225), "Quejoso: Juan Perez Hernandez", fill="#000", font=normal_font)
draw.text((40, 250), "Derechohabiente No. 123456789", fill="#000", font=normal_font)

y = 295
draw.text((40, y), "ASUNTO: Queja por denegacion de servicio medico", fill="#000", font=bold_font)
y += 30
draw.text((40, y), "Estimados senores:", fill="#000", font=normal_font)
y += 30

parrafos = [
    "Por medio del presente escrito, el suscrito Juan Perez Hernandez,",
    "derechohabiente de esta institucion, presento formal queja en contra del",
    "personal medico del CMF Tlahuac, por la denegacion de atencion medica",
    "el dia 15 de junio del presente ano.",
    "",
    "Los hechos ocurrieron aproximadamente a las 09:30 horas, cuando acudi",
    "al consultorio 4 para recibir atencion por un dolor agudo en el pecho",
    "que venia sintiendo desde la noche anterior. La medico de turno,",
    "la Dra. (nombre desconocido), se nego a atenderme argumentando que",
    "no tenia cita previa, a pesar de manifestarle la urgencia del caso.",
    "",
    "Solicito se investiguen los hechos, se sancione al personal responsable",
    "y se me otorgue la atencion medica correspondiente. Asimismo, pido",
    "disculpas formales por el trato recibido.",
    "",
    "Agradezco de antemano su atencion y quedo a la espera de una pronta",
    "respuesta en terminos del articulo 33 de la Ley de los Derechos de",
    "las Personas Usuarias del ISSSTE.",
]

for p in parrafos:
    draw.text((40, y), p, fill="#000", font=normal_font)
    y += 22

y += 10
draw.text((40, y), "Atentamente,", fill="#000", font=normal_font)
y += 30
draw.text((40, y), "Juan Perez Hernandez", fill="#000", font=bold_font)
y += 22
draw.text((40, y), "Tel: 55 1234 5678", fill="#666", font=small_font)

out = "/home/z/my-project/download/queja_ejemplo.png"
os.makedirs(os.path.dirname(out), exist_ok=True)
img.save(out, "PNG")
print(f"Imagen de prueba creada en: {out}")
print(f"Tamano: {os.path.getsize(out)} bytes")
