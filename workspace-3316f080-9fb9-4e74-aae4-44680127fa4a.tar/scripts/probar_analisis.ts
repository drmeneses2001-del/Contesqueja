/**
 * Prueba el endpoint /api/analyze con la imagen IMG_8736.jpeg
 * para reproducir el error que reporta el usuario.
 */
import fs from "fs";

const IMG_PATH = "/home/z/my-project/upload/IMG_8736.jpeg";

async function main() {
  const buf = fs.readFileSync(IMG_PATH);
  console.log(`Imagen: ${buf.length} bytes (${(buf.length / 1024 / 1024).toFixed(2)} MB)`);

  const b64 = buf.toString("base64");
  const dataUrl = `data:image/jpeg;base64,${b64}`;
  console.log(`Data URL length: ${dataUrl.length} chars (~${(dataUrl.length / 1024 / 1024).toFixed(2)} MB)`);

  console.log("Enviando a /api/analyze ...");
  const t0 = Date.now();
  try {
    const res = await fetch("http://localhost:3000/api/analyze", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ images: [dataUrl] }),
    });
    const elapsed = ((Date.now() - t0) / 1000).toFixed(1);
    console.log(`Status: ${res.status} en ${elapsed}s`);

    const text = await res.text();
    try {
      const json = JSON.parse(text);
      console.log("Respuesta JSON:");
      console.log(JSON.stringify(json, null, 2).slice(0, 3000));
    } catch {
      console.log("Respuesta texto (no JSON):");
      console.log(text.slice(0, 3000));
    }
  } catch (e) {
    console.error("Error de fetch:", e);
  }
}

main();
