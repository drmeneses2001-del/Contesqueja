"""
Recorta regiones específicas del PDF renderizado para extraer:
- Logo conjunto Gobierno México + ISSSTE + Hospital (encabezado izquierdo)
- Ilustración derecha (encabezado)
- Ilustración pie de página izquierda (Margarita Maza)
- Texto pie de página derecho (dirección del hospital)
"""
from PIL import Image
import os

src = '/home/z/my-project/upload/formato_hires.png'
img = Image.open(src)
W, H = img.size
print(f'Imagen original: {W}x{H}')

out_dir = '/home/z/my-project/public'
os.makedirs(out_dir, exist_ok=True)

# Basado en análisis visual del PDF (coordenadas aproximadas)
# El PDF es tamaño carta (595 x 808 pts), renderizado a 4x => 2382 x 3232

# Encabezado izquierdo: logos Gobierno/ISSSTE/Hospital (aprox 0%-50% width, 3%-15% height)
enc_izq = img.crop((60, 100, int(W * 0.55), int(H * 0.16)))
enc_izq.save(f'{out_dir}/header_logos.png')
print(f'header_logos.png: {enc_izq.size}')

# Encabezado derecho: ilustración histórica (aprox 75%-95% width, 3%-18% height)
enc_der = img.crop((int(W * 0.72), 80, int(W * 0.96), int(H * 0.20)))
enc_der.save(f'{out_dir}/header_ilustracion.png')
print(f'header_ilustracion.png: {enc_der.size}')

# Pie de página izquierdo: ilustración Margarita Maza
pie_izq = img.crop((100, int(H * 0.88), int(W * 0.25), int(H * 0.97)))
pie_izq.save(f'{out_dir}/footer_ilustracion.png')
print(f'footer_ilustracion.png: {pie_izq.size}')

# Crop tighter para el pie derecho (sólo como referencia, no se usará como imagen)
pie_der = img.crop((int(W * 0.30), int(H * 0.92), int(W * 0.95), int(H * 0.97)))
pie_der.save(f'{out_dir}/footer_texto_ref.png')
print(f'footer_texto_ref.png: {pie_der.size}')

print('Logos extraídos correctamente.')
