// Generar PDF directamente con jsPDF en Node
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import * as fs from "fs";

// Cargar logos como buffers
const headerLogos = fs.readFileSync("/home/z/my-project/public/header_logos.png");
const headerIlustracion = fs.readFileSync("/home/z/my-project/public/header_ilustracion.png");
const footerIlustracion = fs.readFileSync("/home/z/my-project/public/footer_ilustracion.png");

const headerLogosB64 = headerLogos.toString("base64");
const headerIlustracionB64 = headerIlustracion.toString("base64");
const footerIlustracionB64 = footerIlustracion.toString("base64");

const doc = new jsPDF({ unit: "pt", format: "letter" });
const pageWidth = doc.internal.pageSize.getWidth();
const pageHeight = doc.internal.pageSize.getHeight();
const margin = 50;
const maxWidth = pageWidth - margin * 2;

// Encabezado: logos izquierda
doc.addImage(headerLogosB64, "PNG", margin, 30, 230, 60);
// Encabezado: ilustración derecha
doc.addImage(headerIlustracionB64, "PNG", pageWidth - margin - 60, 28, 55, 65);

let cursorY = 100;
doc.setDrawColor(120, 120, 120);
doc.setLineWidth(0.6);
doc.line(margin, cursorY, pageWidth - margin, cursorY);
cursorY += 18;

// Bloque institucional
const lineasInstitucion = [
  "DIRECCIÓN MÉDICA",
  'HOSPITAL REGIONAL "LIC. ADOLFO LÓPEZ MATEOS"',
  "DIRECCIÓN",
  "SUBDIRECCIÓN MÉDICA",
  "COORDINACIÓN DE GINECOLOGÍA Y OBSTETRICIA",
];

doc.setFont("helvetica", "bold");
doc.setFontSize(9);
doc.setTextColor(20, 20, 20);
for (const linea of lineasInstitucion) {
  doc.text(linea, pageWidth - margin, cursorY, { align: "right" });
  cursorY += 12;
}

cursorY += 6;
doc.setFontSize(9);
doc.setFont("helvetica", "bold");
doc.text("Oficio No. CGO/1234/2026", pageWidth - margin, cursorY, { align: "right" });
cursorY += 14;
doc.setFont("helvetica", "normal");
doc.setFontSize(9);
doc.setTextColor(40, 40, 40);
doc.text("Ciudad de México, a 7 de julio de 2026", pageWidth - margin, cursorY, { align: "right" });
cursorY += 18;

// Destinatario
doc.setFont("helvetica", "bold");
doc.setFontSize(10);
doc.setTextColor(20, 20, 20);
doc.text("LIC. MARÍA DEL ROCÍO PAZ OROPEZA", margin, cursorY);
cursorY += 13;
doc.setFont("helvetica", "normal");
doc.setFontSize(9);
doc.setTextColor(60, 60, 60);
doc.text("COORD. DE ATENCIÓN AL DERECHOHABIENTE", margin, cursorY);
cursorY += 13;
doc.text("P R E S E N T E.-", margin, cursorY);
cursorY += 22;

// Asunto
doc.setFont("helvetica", "bold");
doc.setFontSize(9.5);
doc.setTextColor(20, 20, 20);
doc.text("ASUNTO: CONTESTACIÓN A QUEJA POR DENEGACIÓN DE SERVICIO MÉDICO", margin, cursorY);
cursorY += 20;

// Cuerpo
doc.setFont("helvetica", "normal");
doc.setFontSize(10.5);
doc.setTextColor(30, 30, 30);

const textoRespuesta = `Estimada Ciudadana Derechohabiente:

Recibimos su queja con folio ISSSTE-CDMX-2024-09876, presentada el 15 de junio de 2024, en la que se denuncia la denegación de atención médica en la Clínica Médico Familiar Tláhuac, consultorio 4. Agradecemos su confianza al informarnos sobre este hecho, que ha sido analizado conforme a la normatividad aplicable.

ANTECEDENTES
El día 15 de junio de 2024, aproximadamente a las 09:30 horas, usted acudió al consultorio 4 para solicitar atención médica por un dolor agudo en el pecho que presentaba desde la noche anterior. Según su narración, la médica de turno se negó a proporcionarle la atención requerida argumentando la falta de cita previa, a pesar de la urgencia del caso que usted manifestó.

RESPUESTA
El ISSSTE reconoce el derecho de toda persona a la protección de la salud consagrado en el artículo 4 de la Constitución Política de los Estados Unidos Mexicanos, así como el derecho a recibir servicios de salud oportunos y de calidad previsto en el artículo 51 de la Ley General de Salud. En este sentido, lamentamos profundamente la experiencia que usted refiere y le ofrecemos una disculpa institucional por el trato recibido.

Conforme al artículo 33 de la Ley de los Derechos de las Personas Usuarias y Pacientes del ISSSTE, hemos iniciado un procedimiento administrativo interno para investigar los hechos señalados, el cual será resuelto en un plazo no mayor a 30 días hábiles. Asimismo, se ha agendado una cita prioritaria para su valoración médica en un plazo máximo de 24 horas.

COMPROMISOS
1. Atención médica prioritaria en un plazo no mayor a 24 horas, gestionada a través de la Coordinación de Atención al Derechohabiente.
2. Investigación interna de los hechos descritos, conforme al Reglamento Interior del ISSSTE.
3. Resolución del procedimiento administrativo en un plazo máximo de 30 días hábiles, comunicada por escrito.

Quedamos a su disposición para cualquier aclaración adicional y agradecemos nuevamente su confianza en este Instituto.

Atentamente,`;

const parrafos = textoRespuesta.split(/\n\n/);
for (const p of parrafos) {
  const lines = doc.splitTextToSize(p.trim(), maxWidth);
  for (const l of lines) {
    if (cursorY > pageHeight - 130) {
      // pie de página
      drawFooter();
      doc.addPage();
      cursorY = margin + 10;
    }
    doc.text(l, margin, cursorY, { align: "justify" });
    cursorY += 14;
  }
  cursorY += 5;
}

// Firma
cursorY += 30;
doc.setDrawColor(80, 80, 80);
doc.setLineWidth(0.5);
doc.line(pageWidth / 2 - 110, cursorY, pageWidth / 2 + 110, cursorY);
cursorY += 13;
doc.setFont("helvetica", "bold");
doc.setFontSize(9.5);
doc.setTextColor(20, 20, 20);
doc.text("DR. ROBERTO MENDOZA GARCÍA", pageWidth / 2, cursorY, { align: "center" });
cursorY += 12;
doc.setFont("helvetica", "normal");
doc.setFontSize(8.5);
doc.setTextColor(80, 80, 80);
doc.text("COORDINADOR DE GINECOLOGÍA Y OBSTETRICIA", pageWidth / 2, cursorY, { align: "center" });

function drawFooter() {
  const footerY = pageHeight - 50;
  doc.addImage(footerIlustracionB64, "PNG", margin, footerY - 25, 35, 35);
  doc.setFont("helvetica", "italic");
  doc.setFontSize(7.5);
  doc.setTextColor(110, 110, 110);
  doc.text("2026, año de", margin + 17, footerY + 14, { align: "center" });
  doc.text("Margarita Maza", margin + 17, footerY + 23, { align: "center" });
  doc.setDrawColor(150, 150, 150);
  doc.setLineWidth(0.4);
  doc.line(margin, footerY - 5, pageWidth - margin, footerY - 5);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(7.5);
  doc.setTextColor(80, 80, 80);
  const dir = "Av. Universidad No. 1321, Col. Axotla, C.P. 01030, alcaldía Álvaro Obregón, CDMX, Tel. (55) 5322-2300";
  doc.text(dir, pageWidth / 2 + 40, footerY + 4, { align: "center" });
}

drawFooter();

const buffer = doc.output("arraybuffer");
fs.writeFileSync("/home/z/my-project/download/prueba_formato_institucional.pdf", Buffer.from(buffer));
console.log("PDF generado correctamente");
