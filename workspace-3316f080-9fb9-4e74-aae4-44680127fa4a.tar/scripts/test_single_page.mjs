/**
 * Genera un PDF de prueba con texto de diferentes longitudes
 * para verificar que TODO cabe en UNA SOLA página tamaño carta.
 */
import { jsPDF } from "jspdf";
import * as fs from "fs";

// Replicar la lógica de generarPdfRespuesta pero en Node puro

const textosPrueba = {
  corto: `Estimada paciente María Fernanda López Pérez:

Recibimos su queja y la hemos turnado a esta Coordinación de Ginecología y Obstetricia para su atención. Es entendible que cualquier situación que genere dudas o inconformidad durante la atención médica sea motivo de preocupación.

La Coordinación se apega al Artículo 4 Constitucional y al Artículo 51 de la Ley General de Salud. Se realizarán las acciones internas correspondientes.

Reiteramos nuestro compromiso con la atención ginecológica y obstétrica.

Atentamente,`,

  medio: `Estimada paciente María Fernanda López Pérez:

Recibimos su queja y la hemos turnado a esta Coordinación de Ginecología y Obstetricia para su atención. Es entendible que cualquier situación que genere dudas o inconformidad durante la atención médica sea motivo de preocupación. El Instituto de Seguridad y Servicios Sociales de los Trabajadores del Estado (ISSSTE) se rige por un marco normativo que garantiza la calidad en la atención y la protección de los derechos de las personas usuarias.

La Coordinación de Ginecología y Obstetricia se apega estrictamente a las disposiciones contenidas en la Constitución Política de los Estados Unidos Mexicanos, en su Artículo 4, que reconoce el derecho a la protección de la salud. Asimismo, se sujeta a lo establecido en la Ley General de Salud, específicamente en su Artículo 51, que obliga a las instituciones a proporcionar servicios de salud oportunos y de calidad, garantizando un trato digno y respetuoso a las pacientes.

En relación con los hechos que nos hace llegar, se realizarán las acciones internas correspondientes para verificar el correcto funcionamiento de los procedimientos y el comportamiento del personal adscrito a esta área. La calidad en la atención y el respeto a los derechos de las usuarias son pilares fundamentales de nuestra práctica diaria, y cualquier desviación de estos estándares se atiende con la seriedad que merece.

Reiteramos nuestro compromiso con la excelencia en la atención ginecológica y obstétrica, así como con la mejora continua de los servicios que ofrecemos. Agradecemos su disposición para comunicarnos esta situación, ya que nos permite fortalecer nuestras acciones y garantizar que cada usuaria reciba la atención que merece.

Atentamente,`,

  largo: `Estimada paciente María Fernanda López Pérez:

Recibimos su queja y la hemos turnado a esta Coordinación de Ginecología y Obstetricia para su atención. Es entendible que cualquier situación que genere dudas o inconformidad durante la atención médica sea motivo de preocupación. El Instituto de Seguridad y Servicios Sociales de los Trabajadores del Estado (ISSSTE) se rige por un marco normativo que garantiza la calidad en la atención y la protección de los derechos de las personas usuarias.

La Coordinación de Ginecología y Obstetricia se apega estrictamente a las disposiciones contenidas en la Constitución Política de los Estados Unidos Mexicanos, en su Artículo 4, que reconoce el derecho a la protección de la salud. Asimismo, se sujeta a lo establecido en la Ley General de Salud, específicamente en su Artículo 51, que obliga a las instituciones a proporcionar servicios de salud oportunos y de calidad, garantizando un trato digno y respetuoso a las pacientes.

En relación con los hechos que nos hace llegar, se realizarán las acciones internas correspondientes para verificar el correcto funcionamiento de los procedimientos y el comportamiento del personal adscrito a esta área. La calidad en la atención y el respeto a los derechos de las usuarias son pilares fundamentales de nuestra práctica diaria, y cualquier desviación de estos estándares se atiende con la seriedad que merece.

Adicionalmente, le informamos que esta Coordinación tiene entre sus funciones principales la atención ginecológica y obstétrica, incluyendo consulta externa, control prenatal, atención del parto, cirugía ginecológica, planificación familiar y detección oportuna de cáncer cérvico-uterino y mamario. En todas estas áreas trabajamos con personal especializado y residentes en formación.

Reiteramos nuestro compromiso con la excelencia en la atención ginecológica y obstétrica, así como con la mejora continua de los servicios que ofrecemos. Agradecemos su disposición para comunicarnos esta situación, ya que nos permite fortalecer nuestras acciones y garantizar que cada usuaria reciba la atención que merece.

Nuestra institución continuará implementando medidas orientadas a prevenir situaciones como la que usted refiere, con el fin de asegurar que la atención que brindamos cumpla con los más altos estándares de calidad y calidez humana.

Atentamente,`,
};

function testTexto(nombre, textoRespuesta) {
  const doc = new jsPDF({ unit: "pt", format: "letter" });
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 45;
  const maxWidth = pageWidth - margin * 2;

  const headerEndY = 110;
  const bloqueInstitucionalHeight = 104;
  const destinatarioHeight = 57;
  const asuntoHeight = 24;
  const firmaHeight = 77;
  const footerHeight = 70;

  const fixedHeight = headerEndY + bloqueInstitucionalHeight + destinatarioHeight + asuntoHeight + firmaHeight + footerHeight;
  const availableBodyHeight = pageHeight - fixedHeight;

  const parrafos = textoRespuesta.split(/\n\s*\n/).map(p => p.trim()).filter(p => p.length > 0);

  let bodyFontSize = 10.5;
  let bodyLineHeight = 14;
  let bodyParagraphGap = 5;
  let bodyLines = [];

  const TAMANOS = [10.5, 10, 9.5, 9, 8.5, 8, 7.5, 7, 6.5, 6];

  for (const size of TAMANOS) {
    bodyFontSize = size;
    bodyLineHeight = size * 1.32;
    bodyParagraphGap = Math.max(3, size * 0.45);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(bodyFontSize);
    bodyLines = [];
    for (const p of parrafos) {
      const lines = doc.splitTextToSize(p, maxWidth);
      bodyLines.push(...lines);
      bodyLines.push("");
    }
    const totalBodyHeight = bodyLines.length * bodyLineHeight;
    if (totalBodyHeight <= availableBodyHeight) break;
  }

  const palabras = textoRespuesta.split(/\s+/).length;
  const lineas = bodyLines.length;
  console.log(`[${nombre}] ${palabras} palabras, ${lineas} líneas, fuente=${bodyFontSize}pt, disponible=${availableBodyHeight.toFixed(0)}pt, body=${(bodyLines.length * bodyLineHeight).toFixed(0)}pt`);

  return doc;
}

testTexto("CORTO", textosPrueba.corto);
testTexto("MEDIO", textosPrueba.medio);
testTexto("LARGO", textosPrueba.largo);
