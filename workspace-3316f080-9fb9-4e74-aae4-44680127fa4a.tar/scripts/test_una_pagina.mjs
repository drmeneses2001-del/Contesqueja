/**
 * Genera un PDF de prueba con el texto de una contestación típica
 * para verificar que produce EXACTAMENTE una sola página.
 */
import { jsPDF } from "jspdf";
import * as fs from "fs";

// Cargar logos
const headerLogos = fs.readFileSync("/home/z/my-project/public/header_logos.png").toString("base64");
const headerIlustracion = fs.readFileSync("/home/z/my-project/public/header_ilustracion.png").toString("base64");
const footerIlustracion = fs.readFileSync("/home/z/my-project/public/footer_ilustracion.png").toString("base64");

const textoRespuesta = `Estimada paciente María Fernanda López Pérez:

Recibimos su queja y la hemos turnado a esta Coordinación de Ginecología y Obstetricia para su atención. Es entendible que cualquier situación que genere dudas o inconformidad durante la atención médica sea motivo de preocupación. El Instituto de Seguridad y Servicios Sociales de los Trabajadores del Estado (ISSSTE) se rige por un marco normativo que garantiza la calidad en la atención y la protección de los derechos de las personas usuarias.

La Coordinación de Ginecología y Obstetricia se apega estrictamente a las disposiciones contenidas en la Constitución Política de los Estados Unidos Mexicanos, en su Artículo 4, que reconoce el derecho a la protección de la salud. Asimismo, se sujeta a lo establecido en la Ley General de Salud, específicamente en su Artículo 51, que obliga a las instituciones a proporcionar servicios de salud oportunos y de calidad, garantizando un trato digno y respetuoso a las pacientes.

En relación con los hechos que nos hace llegar, se realizarán las acciones internas correspondientes para verificar el correcto funcionamiento de los procedimientos y el comportamiento del personal adscrito a esta área. La calidad en la atención y el respeto a los derechos de las usuarias son pilares fundamentales de nuestra práctica diaria, y cualquier desviación de estos estándares se atiende con la seriedad que merece.

Reiteramos nuestro compromiso con la excelencia en la atención ginecológica y obstétrica, así como con la mejora continua de los servicios que ofrecemos. Agradecemos su disposición para comunicarnos esta situación, ya que nos permite fortalecer nuestras acciones y garantizar que cada usuaria reciba la atención que merece.

Atentamente,`;

function generar(textoRespuesta) {
  const doc = new jsPDF({ unit: "pt", format: "letter" });
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 45;
  const maxWidth = pageWidth - margin * 2;

  const headerEndY = 110;
  const bloqueInstitucionalHeight = 104;
  const destinatarioHeight = 57;
  const asuntoHeight = 24;
  const firmaHeight = 77;
  const footerHeight = 70;

  const fixedHeight = headerEndY + bloqueInstitucionalHeight + destinatarioHeight + asuntoHeight + firmaHeight + footerHeight;
  const availableBodyHeight = pageHeight - fixedHeight;

  const parrafos = textoRespuesta.split(/\n\s*\n/).map(p => p.trim()).filter(p => p.length > 0);

  let bodyFontSize = 10.5;
  let bodyLineHeight = 14;
  let bodyParagraphGap = 5;
  let bodyLines = [];

  const TAMANOS = [10.5, 10, 9.5, 9, 8.5, 8, 7.5, 7, 6.5, 6];

  for (const size of TAMANOS) {
    bodyFontSize = size;
    bodyLineHeight = size * 1.32;
    bodyParagraphGap = Math.max(3, size * 0.45);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(bodyFontSize);
    bodyLines = [];
    for (const p of parrafos) {
      const lines = doc.splitTextToSize(p, maxWidth);
      bodyLines.push(...lines);
      bodyLines.push("");
    }
    const totalBodyHeight = bodyLines.length * bodyLineHeight;
    if (totalBodyHeight <= availableBodyHeight) break;
  }

  // Dibujar encabezado
  try { doc.addImage(headerLogos, "PNG", margin, 28, 220, 56); } catch(e) {}
  try { doc.addImage(headerIlustracion, "PNG", pageWidth - margin - 55, 26, 52, 62); } catch(e) {}

  let cursorY = headerEndY - 10;
  doc.setDrawColor(120, 120, 120);
  doc.setLineWidth(0.6);
  doc.line(margin, cursorY, pageWidth - margin, cursorY);
  cursorY = headerEndY;

  const lineasInstitucion = [
    "DIRECCIÓN MÉDICA",
    'HOSPITAL REGIONAL "LIC. ADOLFO LÓPEZ MATEOS"',
    "DIRECCIÓN",
    "SUBDIRECCIÓN MÉDICA",
    "COORDINACIÓN DE GINECOLOGÍA Y OBSTETRICIA",
  ];
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8.5);
  doc.setTextColor(20, 20, 20);
  for (const linea of lineasInstitucion) {
    doc.text(linea, pageWidth - margin, cursorY, { align: "right" });
    cursorY += 11.5;
  }
  cursorY += 4;
  doc.text("Oficio No. CGO/1234/2026", pageWidth - margin, cursorY, { align: "right" });
  cursorY += 13;
  doc.setFont("helvetica", "normal");
  doc.text("Ciudad de México, a 7 de julio de 2026", pageWidth - margin, cursorY, { align: "right" });
  cursorY += 28;

  // Destinatario (funcionario, no la paciente)
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9.5);
  doc.text("LIC. MARÍA DEL ROCÍO PAZ OROPEZA", margin, cursorY);
  cursorY += 12;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8.5);
  doc.setTextColor(60, 60, 60);
  doc.text("COORD. DE ATENCIÓN AL DERECHOHABIENTE", margin, cursorY);
  cursorY += 12;
  doc.text("P R E S E N T E.-", margin, cursorY);
  cursorY += 18;

  // Asunto
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.setTextColor(20, 20, 20);
  doc.text("ASUNTO: CONTESTACIÓN A QUEJA", margin, cursorY);
  cursorY += 20;

  // Cuerpo
  doc.setFont("helvetica", "normal");
  doc.setFontSize(bodyFontSize);
  doc.setTextColor(30, 30, 30);
  for (const linea of bodyLines) {
    if (linea === "") {
      cursorY += bodyParagraphGap;
    } else {
      doc.text(linea, margin, cursorY, { align: "justify", maxWidth: maxWidth });
      cursorY += bodyLineHeight;
    }
  }

  // Firma
  cursorY += 18;
  doc.setDrawColor(80, 80, 80);
  doc.setLineWidth(0.5);
  doc.line(pageWidth / 2 - 110, cursorY, pageWidth / 2 + 110, cursorY);
  cursorY += 12;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.text("DR. ROBERTO MENDOZA GARCÍA", pageWidth / 2, cursorY, { align: "center" });
  cursorY += 11;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.setTextColor(80, 80, 80);
  doc.text("COORDINADOR DE GINECOLOGÍA Y OBSTETRICIA", pageWidth / 2, cursorY, { align: "center" });

  // Pie de página
  const footerY = pageHeight - 55;
  try { doc.addImage(footerIlustracion, "PNG", margin, footerY - 22, 30, 30); } catch(e) {}
  doc.setFont("helvetica", "italic");
  doc.setFontSize(7);
  doc.setTextColor(110, 110, 110);
  doc.text("2026, año de", margin + 15, footerY + 12, { align: "center" });
  doc.text("Margarita Maza", margin + 15, footerY + 20, { align: "center" });
  doc.setDrawColor(150, 150, 150);
  doc.setLineWidth(0.4);
  doc.line(margin, footerY - 5, pageWidth - margin, footerY - 5);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(7);
  doc.setTextColor(80, 80, 80);
  doc.text("Av. Universidad No. 1321, Col. Axotla, C.P. 01030, alcaldía Álvaro Obregón, CDMX, Tel. (55) 5322-2300", pageWidth / 2 + 35, footerY + 3, { align: "center" });

  return doc;
}

const doc = generar(textoRespuesta);
const numPaginas = doc.getNumberOfPages();
console.log(`Número de páginas: ${numPaginas}`);

const buffer = doc.output("arraybuffer");
fs.writeFileSync("/home/z/my-project/download/prueba_una_pagina.pdf", Buffer.from(buffer));
console.log("PDF guardado en /home/z/my-project/download/prueba_una_pagina.pdf");
console.log(`Tamaño: ${(buffer.byteLength / 1024).toFixed(0)} KB`);
